<?xml version='1.0' encoding='UTF-8'?>
<?profile version='1.0.0'?>
<profile id='epp.package.java' timestamp='1348102306414'>
  <properties size='11'>
    <property name='org.eclipse.equinox.p2.environments' value='osgi.arch=x86,osgi.os=win32,osgi.ws=win32,osgi.nl=en_US'/>
    <property name='org.eclipse.equinox.p2.roaming' value='false'/>
    <property name='org.eclipse.update.install.features' value='true'/>
    <property name='org.eclipse.equinox.p2.cache' value='\\netapp2.divms.uiowa.edu\jllawsn\.winprofile\Adobe Flash Builder 4.5\cascaded\308971'/>
    <property name='org.eclipse.equinox.p2.installFolder' value='C:\Program Files (x86)\Adobe\Adobe Flash Builder 4.5\eclipse'/>
    <property name='eclipse.touchpoint.launcherName' value='eclipse'/>
    <property name='org.eclipse.equinox.p2.surrogate' value='true'/>
    <property name='org.eclipse.equinox.p2.shared.timestamp' value='1301933617378'/>
    <property name='org.eclipse.equinox.p2.cache.shared' value='C:\Program Files (x86)\Adobe\Adobe Flash Builder 4.5\eclipse'/>
    <property name='org.eclipse.equinox.p2.configurationFolder' value='\\netapp2.divms.uiowa.edu\jllawsn\.winprofile\Adobe Flash Builder 4.5\cascaded\308971\configuration'/>
    <property name='org.eclipse.equinox.p2.launcherConfiguration' value='\\netapp2.divms.uiowa.edu\jllawsn\.winprofile\Adobe Flash Builder 4.5\cascaded\308971\configuration\eclipse.ini.ignored'/>
  </properties>
  <units size='10'>
    <unit id='SharedProfile_epp.package.java' version='1.0.0.1301933617378' singleton='false'>
      <properties size='1'>
        <property name='org.eclipse.equinox.p2.name' value='Shared profile'/>
      </properties>
      <provides size='1'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='SharedProfile_epp.package.java' version='1.0.0.1301933617378'/>
      </provides>
      <requires size='512'>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.simpleconfigurator.manipulator' range='[2.0.0.v20100503,2.0.0.v20100503]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='com.adobe.flexbuilder.editors.derived.nl1' range='[4.5.0.308971,4.5.0.308971]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ecf' range='[3.1.0.v20100529-0735,3.1.0.v20100529-0735]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.util' range='[1.0.200.v20100503,1.0.200.v20100503]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.wst.common.emfworkbench.integration' range='[1.2.2.v201008242000,1.2.2.v201008242000]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.wst.xml_userdoc.feature.feature.jar' range='[3.2.100.v201005241420-50FXNAkF7B77RBgFFBF,3.2.100.v201005241420-50FXNAkF7B77RBgFFBF]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.discovery.feature.feature.group' range='[1.0.0.v20100510-4--9oB5855K7P,1.0.0.v20100510-4--9oB5855K7P]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.jarprocessor' range='[1.0.200.v20100503a,1.0.200.v20100503a]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.user.ui.feature.jar' range='[2.0.1.r361_v20100903-897HFZFFZRuSD2LMtVxyz0Vr,2.0.1.r361_v20100903-897HFZFFZRuSD2LMtVxyz0Vr]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='com.adobe.flexbuilder.standalone.e36' range='[4.5.0.308971,4.5.0.308971]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.core' range='[2.0.2.R36x_v20100804,2.0.2.R36x_v20100804]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='com.adobe.flexbuilder.launching.ui' range='[4.5.0.308971,4.5.0.308971]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.debug.ui' range='[3.6.1.v20100901_r361,3.6.1.v20100901_r361]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.wst.common.frameworks' range='[1.2.0.v201003040800,1.2.0.v201003040800]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='com.adobe.flexbuilder.mxmlmodel' range='[4.5.0.308971,4.5.0.308971]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ui.navigator' range='[3.5.0.I20100601-0800,3.5.0.I20100601-0800]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='com.adobe.flexbuilder.services.LCDSService' range='[4.5.0.308971,4.5.0.308971]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.update.core' range='[3.2.402.R36x_v20100629,3.2.402.R36x_v20100629]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='javax.servlet.jsp' range='[2.0.0.v200806031607,2.0.0.v200806031607]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='com.adobe.flexbuilder.flexunit.derived' range='[4.5.0.308971,4.5.0.308971]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ui.workbench' range='[3.6.1.M20100826-1330,3.6.1.M20100826-1330]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='javax.wsdl' range='[1.6.2.v200806030405,1.6.2.v200806030405]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='com.adobe.rds.feature.feature.jar' range='[4.5.304901.v20110217,4.5.304901.v20110217]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.jdt.core' range='[3.6.1.v_A68_R36x,3.6.1.v_A68_R36x]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='com.adobe.flexbuilder.flexunit.nl1' range='[4.5.0.308971,4.5.0.308971]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='com.adobe.flash.codemodel.core' range='[4.5.0.308971,4.5.0.308971]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.epp.package.java.feature.feature.group' range='[1.3.1.20100916-1202,1.3.1.20100916-1202]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.apache.xerces' range='[2.9.0.v201005080400,2.9.0.v201005080400]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.discovery.compatibility' range='[1.0.0.v20100518,1.0.0.v20100518]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.apache.commons.logging' range='[1.0.4.v200904062259,1.0.4.v200904062259]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.apache.commons.logging' range='[1.0.4.v201005080501,1.0.4.v201005080501]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='com.adobe.flexide.fonts' range='[4.5.0.308971,4.5.0.308971]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.platform' range='[3.6.1.v201009090800,3.6.1.v201009090800]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='com.adobe.flexide.editorcore.nl1' range='[4.5.0.308971,4.5.0.308971]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.wst.sse.ui' range='[1.2.2.v201008232126,1.2.2.v201008232126]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.mylyn.tasks.bugs' range='[3.4.1.v20100823-0100-e3x,3.4.1.v20100823-0100-e3x]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.apache.commons.lang' range='[2.3.0.v201005080501,2.3.0.v201005080501]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.epp.mpc.help.ui' range='[1.0.0.v20100826-2143,1.0.0.v20100826-2143]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.help' range='[3.5.0.v20100524,3.5.0.v20100524]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.wst.common.snippets' range='[1.2.1.v201008251905,1.2.1.v201008251905]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.epp.mpc.feature.jar' range='[1.0.1.v20100826-2143,1.0.1.v20100826-2143]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.wst.validation' range='[1.2.200.v201005271900,1.2.200.v201005271900]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='com.adobe.flexbuilder.ui.nl1' range='[4.5.0.308971,4.5.0.308971]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='com.adobe.flexbuilder.project' range='[4.5.0.308971,4.5.0.308971]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.team.cvs.ui' range='[3.3.301.R36x_v20100825-0800,3.3.301.R36x_v20100825-0800]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='com.adobe.flexbuilder.services.J2EEService' range='[4.5.0.308971,4.5.0.308971]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.epp.package.common' range='[1.3.1.20100913-1228,1.3.1.20100913-1228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.reconciler.dropins' range='[1.1.0.v20100525,1.1.0.v20100525]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.preferences' range='[3.3.0.v20100503,3.3.0.v20100503]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.mylyn.bugzilla_feature.feature.group' range='[3.4.2.v20100916-0100-e3x-7D773BgJ9DH9fCc4CICE1,3.4.2.v20100916-0100-e3x-7D773BgJ9DH9fCc4CICE1]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='com.adobe.flexide.feature.feature.group' range='[4.5.0.308971,4.5.0.308971]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.metadata.generator' range='[1.0.200.v20100503a,1.0.200.v20100503a]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.mylyn.wikitext.tracwiki.ui' range='[1.3.0.v20100608-0100-e3x,1.3.0.v20100608-0100-e3x]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.mylyn.tasks.core' range='[3.4.1.v20100730-0100-e3x,3.4.1.v20100730-0100-e3x]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.junit4' range='[4.8.1.v20100525,4.8.1.v20100525]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ui.views.log' range='[1.0.100.v20100423,1.0.100.v20100423]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.mylyn.bugzilla_feature.feature.jar' range='[3.4.2.v20100916-0100-e3x-7D773BgJ9DH9fCc4CICE1,3.4.2.v20100916-0100-e3x-7D773BgJ9DH9fCc4CICE1]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.ds' range='[1.2.1.R36x_v20100803,1.2.1.R36x_v20100803]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.help.base' range='[3.5.2.v201009090800,3.5.2.v201009090800]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='com.adobe.flexbuilder.flashbridge.nl1' range='[4.5.0.308971,4.5.0.308971]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.jdt' range='[3.6.1.v201009090800,3.6.1.v201009090800]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.osgi.util' range='[3.2.100.v20100503,3.2.100.v20100503]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='com.adobe.flexbuilder.standalone' range='[4.5.0.308971,4.5.0.308971]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='com.adobe.flexbuilder.css.editor' range='[4.5.0.308971,4.5.0.308971]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='com.adobe.flexbuilder.services.StaticContentService.nl1' range='[4.5.0.308971,4.5.0.308971]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.jdt.junit4.runtime' range='[1.1.100.v20100526-0800,1.1.100.v20100526-0800]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.artifact.repository' range='[1.1.1.R36x_v20100901,1.1.1.R36x_v20100901]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.wst.xml.ui.infopop' range='[1.0.400.v201004292007,1.0.400.v201004292007]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='com.adobe.flexbuilder.feature.core.nl1.feature.jar' range='[4.5.0.308971,4.5.0.308971]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ui.navigator.resources' range='[3.4.201.M20100707-0800,3.4.201.M20100707-0800]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.wst.common.core' range='[1.2.0.v200908252030,1.2.0.v200908252030]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='com.adobe.flexide.refactoring.core.nl1' range='[4.5.0.308971,4.5.0.308971]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='com.adobe.flexbuilder.debug' range='[4.5.0.308971,4.5.0.308971]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.mylyn.wikitext.tasks.ui' range='[1.3.1.v20100823-0100-e3x,1.3.1.v20100823-0100-e3x]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.jsch.core' range='[1.1.200.I20100505-1245,1.1.200.I20100505-1245]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='javax.servlet' range='[2.5.0.v200910301333,2.5.0.v200910301333]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.wst.xml.ui' range='[1.1.102.v201008251905,1.1.102.v201008251905]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.mylyn.commons.net' range='[3.4.1.v20100625-2100-e3x,3.4.1.v20100625-2100-e3x]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.updatesite' range='[1.0.201.R36x_v20100823,1.0.201.R36x_v20100823]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.mylyn.wikitext.core' range='[1.3.1.v20100823-0100-e3x,1.3.1.v20100823-0100-e3x]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='com.adobe.flexbuilder.services.WEBService.nl1' range='[4.5.0.308971,4.5.0.308971]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.mylyn.monitor.core' range='[3.4.0.v20100608-0100-e3x,3.4.0.v20100608-0100-e3x]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.wst.xml_core.feature.feature.group' range='[3.2.2.v201008170029-7C7OFXYF7RZHQHI5PyJwPT,3.2.2.v201008170029-7C7OFXYF7RZHQHI5PyJwPT]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='com.adobe.flexbuilder.ui' range='[4.5.0.308971,4.5.0.308971]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='com.adobe.flexbuilder.axis2' range='[4.5.0.308971,4.5.0.308971]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ecf.provider.filetransfer.ssl' range='[1.0.0.v20100529-0735,1.0.0.v20100529-0735]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='com.adobe.flexbuilder.dcrad.nl1' range='[4.5.0.308971,4.5.0.308971]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ui.ide.application' range='[1.0.201.M20100707-0800,1.0.201.M20100707-0800]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='com.adobe.flexbuilder.DCDService.nl1' range='[4.5.0.308971,4.5.0.308971]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.metadata' range='[2.0.0.v20100601,2.0.0.v20100601]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='tooling.org.eclipse.update.feature.default' range='[1.0.0,1.0.0]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='com.adobe.flexbuilder.ajaxbridge.nl1' range='[4.5.0.308971,4.5.0.308971]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='com.adobe.flexide.utils.feature.feature.jar' range='[4.5.0.308971,4.5.0.308971]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='com.adobe.flexbuilder.mxml.editor' range='[4.5.0.308971,4.5.0.308971]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.rcp.feature.jar' range='[3.6.1.r361_v20100827-9OArFLdFjY-ThSQXmKvKz0_T,3.6.1.r361_v20100827-9OArFLdFjY-ThSQXmKvKz0_T]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.wst.common.project.facet.core' range='[1.4.102.v201008170019,1.4.102.v201008170019]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.apache.xml.resolver' range='[1.2.0.v201005080400,1.2.0.v201005080400]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='com.adobe.flexide.multiplatform.ios' range='[4.5.0.308971,4.5.0.308971]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.gef' range='[3.6.1.v20100712-1224,3.6.1.v20100712-1224]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='com.adobe.flexbuilder.flex' range='[4.5.0.308971,4.5.0.308971]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='com.adobe.flexbuilder.flexunit' range='[4.5.0.308971,4.5.0.308971]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.jdt.compiler.tool' range='[1.0.100.v_A68_R36x,1.0.100.v_A68_R36x]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.mylyn.commons.ui' range='[3.4.0.v20100608-0100-e3x,3.4.0.v20100608-0100-e3x]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.rcp' range='[3.6.0.v201009090800,3.6.0.v201009090800]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='com.adobe.flashbuilder.launching.multiplatform.ui.nl1' range='[4.5.0.308971,4.5.0.308971]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='com.adobe.flexbuilder.crimson.nl1' range='[4.5.0.308971,4.5.0.308971]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='com.adobe.flexbuilder.feature.standalone.nl1.feature.jar' range='[4.5.0.308971,4.5.0.308971]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.mylyn.wikitext.confluence.core' range='[1.3.0.v20100608-0100-e3x,1.3.0.v20100608-0100-e3x]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.mylyn.wikitext.textile.ui' range='[1.3.0.v20100608-0100-e3x,1.3.0.v20100608-0100-e3x]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='com.adobe.flexide.editorcore' range='[4.5.0.308971,4.5.0.308971]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.mylyn.ide_feature.feature.group' range='[3.4.2.v20100916-0100-e3x-7G7J2BgJ9E99jDd49E994,3.4.2.v20100916-0100-e3x-7G7J2BgJ9E99jDd49E994]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.mylyn.team_feature.feature.group' range='[3.4.2.v20100916-0100-e3x-4317w31211A1A012110,3.4.2.v20100916-0100-e3x-4317w31211A1A012110]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.http.jetty' range='[2.0.0.v20100503,2.0.0.v20100503]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='javax.xml.bind' range='[2.0.0.v20080604-1500,2.0.0.v20080604-1500]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='com.adobe.flexbuilder.editorcore' range='[4.5.0.308971,4.5.0.308971]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='com.adobe.flexbuilder.feature.standalone.feature.group' range='[4.5.0.308971,4.5.0.308971]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='com.adobe.flexbuilder.debug.nl1' range='[4.5.0.308971,4.5.0.308971]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ui.views' range='[3.5.0.I20100527-0800,3.5.0.I20100527-0800]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.common' range='[3.6.0.v20100503,3.6.0.v20100503]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.help.feature.group' range='[1.2.0.v20100427-7e7jEQFEp4jsWcboLU9l93,1.2.0.v20100427-7e7jEQFEp4jsWcboLU9l93]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.mylyn.bugzilla.ide' range='[3.4.0.v20100608-0100-e3x,3.4.0.v20100608-0100-e3x]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ui.workbench.texteditor' range='[3.6.1.r361_v20100714-0800,3.6.1.r361_v20100714-0800]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.wst.common.uriresolver' range='[1.1.401.v201004280700,1.1.401.v201004280700]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='com.adobe.flexide.designitems' range='[4.5.0.308971,4.5.0.308971]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='com.adobe.flexide.mxml.core.nl1' range='[4.5.0.308971,4.5.0.308971]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.wst.dtd.core' range='[1.1.400.v201004290328,1.1.400.v201004290328]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.runtime.compatibility.auth' range='[3.2.200.v20100517,3.2.200.v20100517]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.rcp.feature.group' range='[3.6.1.r361_v20100827-9OArFLdFjY-ThSQXmKvKz0_T,3.6.1.r361_v20100827-9OArFLdFjY-ThSQXmKvKz0_T]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ant.core' range='[3.2.200.v20100427,3.2.200.v20100427]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='toolingorg.eclipse.equinox.launcher' range='[1.1.0.v20100507,1.1.0.v20100507]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ant.launching' range='[1.0.0.v20100427,1.0.0.v20100427]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='com.adobe.flexbuilder.help' range='[4.5.0.308971,4.5.0.308971]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='com.jcraft.jsch' range='[0.1.41.v200903070017,0.1.41.v200903070017]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.mylyn.bugzilla.ui' range='[3.4.2.v20100909-0100-e3x,3.4.2.v20100909-0100-e3x]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ui.win32' range='[3.2.200.I20100509-0800,3.2.200.I20100509-0800]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.apache.ws.commons.util' range='[1.0.0.v20100518-1135,1.0.0.v20100518-1135]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.wst.common.modulecore' range='[1.2.3.v201008242000,1.2.3.v201008242000]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='toolingwin32.win32.x86org.eclipse.equinox.p2.reconciler.dropins' range='[3.6.1.M20100909-0800,3.6.1.M20100909-0800]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ui.workbench.compatibility' range='[3.2.100.I20100511-0800,3.2.100.I20100511-0800]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='com.adobe.model.feature.core.feature.group' range='[4.5.304901.v20110217,4.5.304901.v20110217]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.mylyn.monitor.ui' range='[3.4.0.v20100608-0100-e3x,3.4.0.v20100608-0100-e3x]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='com.adobe.flexbuilder.feature.core.feature.group' range='[4.5.0.308971,4.5.0.308971]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.epp.usagedata.feature.feature.group' range='[1.3.0.R201005261100,1.3.0.R201005261100]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.jface.text' range='[3.6.1.r361_v20100825-0800,3.6.1.r361_v20100825-0800]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.apache.commons.el' range='[1.0.0.v201004212143,1.0.0.v201004212143]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.compare.win32' range='[1.0.100.I20100505-1245,1.0.100.I20100505-1245]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.runtime' range='[3.6.0.v20100505,3.6.0.v20100505]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.jdt.ui' range='[3.6.1.r361_v20100825-0800,3.6.1.r361_v20100825-0800]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.mylyn.wikitext.mediawiki.core' range='[1.3.0.v20100608-0100-e3x,1.3.0.v20100608-0100-e3x]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='com.adobe.flexide.fcproject' range='[4.5.0.308971,4.5.0.308971]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='com.adobe.flexbuilder.services.PHPService.nl1' range='[4.5.0.308971,4.5.0.308971]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ui.forms' range='[3.5.2.r36_v20100702,3.5.2.r36_v20100702]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.mylyn.wikitext.textile.core' range='[1.3.0.v20100608-0100-e3x,1.3.0.v20100608-0100-e3x]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.mortbay.jetty.util' range='[6.1.23.v201004211559,6.1.23.v201004211559]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.director' range='[2.0.2.R36x_v20100823,2.0.2.R36x_v20100823]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.wst.common_core.feature.feature.jar' range='[3.2.2.v201008091400-7B7DFElF7RZHOZJ6W0PsNJ,3.2.2.v201008091400-7B7DFElF7RZHOZJ6W0PsNJ]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.filesystem' range='[1.3.1.R36x_v20100727-0745,1.3.1.R36x_v20100727-0745]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='a.jre.javase' range='[1.6.0,1.6.0]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.epp.package.common.feature.feature.group' range='[1.3.1.20100916-1202,1.3.1.20100916-1202]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.mylyn.wikitext.twiki.core' range='[1.3.0.v20100608-0100-e3x,1.3.0.v20100608-0100-e3x]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.team.cvs.ssh2' range='[3.2.300.I20100526-0800,3.2.300.I20100526-0800]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.variables' range='[3.2.400.v20100505,3.2.400.v20100505]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.externaltools' range='[1.0.1.v20100831_r361,1.0.1.v20100831_r361]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.operations' range='[2.0.0.v20100510,2.0.0.v20100510]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.touchpoint.eclipse' range='[2.0.2.R36x_v20100823,2.0.2.R36x_v20100823]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='com.adobe.flashbuilder.multiplatform.ios.ui' range='[4.5.0.308971,4.5.0.308971]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.mylyn.tasks.ui' range='[3.4.2.v20100902-0100-e3x,3.4.2.v20100902-0100-e3x]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.metadata.repository' range='[1.1.0.v20100513,1.1.0.v20100513]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.wst.dtd.ui' range='[1.0.500.v201004290328,1.0.500.v201004290328]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.team.cvs.core' range='[3.3.300.I20100526-0800,3.3.300.I20100526-0800]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.jdt.apt.pluggable.core' range='[1.0.301.R36_v20100727-0110,1.0.301.R36_v20100727-0110]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.wst.xml.core' range='[1.1.502.v201009010342,1.1.502.v201009010342]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.emf.edit.ui' range='[2.6.0.v20100914-1218,2.6.0.v20100914-1218]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.wst.sse.ui.infopop' range='[1.0.300.v201004150328,1.0.300.v201004150328]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='com.adobe.flash.profiler.nl1' range='[4.5.0.308971,4.5.0.308971]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.text' range='[3.5.0.v20100601-1300,3.5.0.v20100601-1300]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='com.adobe.flexide.exportimport' range='[4.5.0.308971,4.5.0.308971]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='com.adobe.flexbuilder.multisdk' range='[4.5.0.308971,4.5.0.308971]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='com.adobe.flexbuilder.axis2.nl1' range='[4.5.0.308971,4.5.0.308971]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.director.app' range='[1.0.201.R36x_v20100823,1.0.201.R36x_v20100823]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.wst.server.core' range='[1.1.204.v20100908,1.1.204.v20100908]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='com.adobe.flexbuilder.monitors.network' range='[4.5.0.308971,4.5.0.308971]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.jdt.debug.ui' range='[3.5.0.v20100602-0830,3.5.0.v20100602-0830]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='com.adobe.flexide.launching' range='[4.5.0.308971,4.5.0.308971]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.wst.common_ui.feature.feature.jar' range='[3.2.2.v201008091400-7C78FPhEdhO_mXde7kbap_K7X1Qt,3.2.2.v201008091400-7C78FPhEdhO_mXde7kbap_K7X1Qt]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.mylyn.context.core' range='[3.4.1.v20100909-0100-e3x,3.4.1.v20100909-0100-e3x]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.wst.sse.core' range='[1.1.502.v201008311901,1.1.502.v201008311901]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='com.adobe.flexbuilder.services.CFService.nl1' range='[4.5.0.308971,4.5.0.308971]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.engine' range='[2.0.0.v20100606,2.0.0.v20100606]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.epp.usagedata.feature.feature.jar' range='[1.3.0.R201005261100,1.3.0.R201005261100]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='toolingwin32.win32.x86org.eclipse.equinox.ds' range='[3.6.1.M20100909-0800,3.6.1.M20100909-0800]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='com.adobe.flexbuilder.project.nl1' range='[4.5.0.308971,4.5.0.308971]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.mylyn.java_feature.feature.group' range='[3.4.2.v20100916-0100-e3x-7D7F-AkF7B77V7c37B773,3.4.2.v20100916-0100-e3x-7D7F-AkF7B77V7c37B773]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='com.adobe.flexbuilder.editors.derived' range='[4.5.0.308971,4.5.0.308971]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.filesystem.win32.x86' range='[1.1.201.R36x_v20100727-0745,1.1.201.R36x_v20100727-0745]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='com.adobe.flexbuilder.dcrad.derived' range='[4.5.0.308971,4.5.0.308971]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.jsp.jasper' range='[1.0.200.v20100421,1.0.200.v20100421]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='com.adobe.flexide.communityhelp.nl1' range='[4.5.0.308971,4.5.0.308971]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.wst.common_core.feature.feature.group' range='[3.2.2.v201008091400-7B7DFElF7RZHOZJ6W0PsNJ,3.2.2.v201008091400-7B7DFElF7RZHOZJ6W0PsNJ]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.mylyn.help.ui' range='[3.4.1.v20100823-0100-e3x,3.4.1.v20100823-0100-e3x]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.help.feature.jar' range='[1.2.0.v20100427-7e7jEQFEp4jsWcboLU9l93,1.2.0.v20100427-7e7jEQFEp4jsWcboLU9l93]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='com.adobe.flexbuilder.services.WEBService' range='[4.5.0.308971,4.5.0.308971]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='com.adobe.flexbuilder.feature.standalone.nl1.feature.group' range='[4.5.0.308971,4.5.0.308971]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.wst.internet.cache' range='[1.0.400.v201004280700,1.0.400.v201004280700]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='com.adobe.flexbuilder.feature.standalone.feature.jar' range='[4.5.0.308971,4.5.0.308971]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.jdt.launching' range='[3.5.100.v20100526,3.5.100.v20100526]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.expressions' range='[3.4.200.v20100505,3.4.200.v20100505]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.wst.common.frameworks.ui' range='[1.2.0.v201004080500,1.2.0.v201004080500]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ui.intro.universal' range='[3.2.402.r36_v20100702,3.2.402.r36_v20100702]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='epp.package.java' range='[1.3.1.20100916-1202,1.3.1.20100916-1202]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.epp.mpc.feature.group' range='[1.0.1.v20100826-2143,1.0.1.v20100826-2143]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.mylyn.context_feature.feature.group' range='[3.4.2.v20100916-0100-e3x-777718s73533L3L135331,3.4.2.v20100916-0100-e3x-777718s73533L3L135331]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.mylyn.wikitext.mediawiki.ui' range='[1.3.0.v20100608-0100-e3x,1.3.0.v20100608-0100-e3x]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.wst.xml_userdoc.feature.feature.group' range='[3.2.100.v201005241420-50FXNAkF7B77RBgFFBF,3.2.100.v201005241420-50FXNAkF7B77RBgFFBF]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='com.adobe.flexbuilder.tengine' range='[4.5.0.308971,4.5.0.308971]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='com.adobe.flexide.nativelibs' range='[4.5.0.308971,4.5.0.308971]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='com.adobe.flexide.multiplatform.ios.nl1' range='[4.5.0.308971,4.5.0.308971]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='com.adobe.flexide.launching.nl1' range='[4.5.0.308971,4.5.0.308971]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.mylyn.wikitext.tracwiki.core' range='[1.3.0.v20100608-0100-e3x,1.3.0.v20100608-0100-e3x]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ui.views.properties.tabbed' range='[3.5.100.I20100509-0800,3.5.100.I20100509-0800]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='com.adobe.flexbuilder.services.StaticContentService' range='[4.5.0.308971,4.5.0.308971]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='com.adobe.flexbuilder.utils.osnative.win' range='[4.5.0.308971,4.5.0.308971]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.runtime.compatibility' range='[3.2.100.v20100505,3.2.100.v20100505]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='com.adobe.flexbuilder.utils.osnative' range='[4.5.0.308971,4.5.0.308971]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ant.ui' range='[3.5.0.v20100427,3.5.0.v20100427]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='com.adobe.flexbuilder.DCDService' range='[4.5.0.308971,4.5.0.308971]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ecf.provider.filetransfer.httpclient.ssl' range='[1.0.0.v20100529-0735,1.0.0.v20100529-0735]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.mylyn.commons.xmlrpc' range='[3.4.0.v20100608-0100-e3x,3.4.0.v20100608-0100-e3x]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.wst.common.environment' range='[1.0.400.v200912181832,1.0.400.v200912181832]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.boot' range='[3.1.200.v20100505,3.1.200.v20100505]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.launcher.win32.win32.x86' range='[1.1.1.R36x_v20100810,1.1.1.R36x_v20100810]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.epp.mpc.core' range='[1.0.0.v20100826-2143,1.0.0.v20100826-2143]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.help.webapp' range='[3.5.2.r36_r20100816,3.5.2.r36_r20100816]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.sat4j.core' range='[2.2.0.v20100429,2.2.0.v20100429]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='com.adobe.flexbuilder.debug.ui.actions' range='[4.5.0.308971,4.5.0.308971]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='com.adobe.flexbuilder.importartwork' range='[4.5.0.308971,4.5.0.308971]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='com.adobe.flashbuilder.multiplatform.android.ui.nl1' range='[4.5.0.308971,4.5.0.308971]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='com.adobe.flexide.multisdk.nl1' range='[4.5.0.308971,4.5.0.308971]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='toolingorg.eclipse.configuration' range='[1.0.0,1.0.0]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.mylyn.team.ui' range='[3.4.2.v20100909-0100-e3x,3.4.2.v20100909-0100-e3x]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='config.a.jre.javase' range='[1.6.0,1.6.0]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.discovery' range='[1.0.0.v20100503,1.0.0.v20100503]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.console' range='[1.0.200.v20100601,1.0.200.v20100601]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.updatechecker' range='[1.1.101.R36x_v20100823,1.1.101.R36x_v20100823]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.xsd.edit' range='[2.6.0.v20100914-1218,2.6.0.v20100914-1218]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='com.adobe.flexbuilder.designview' range='[4.5.0.308971,4.5.0.308971]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.frameworkadmin' range='[2.0.0.v20100503,2.0.0.v20100503]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='com.adobe.flexide.project.multiplatform.nl1' range='[4.5.0.308971,4.5.0.308971]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.compare.core' range='[3.5.100.I20100526-0800,3.5.100.I20100526-0800]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.jdt.apt.core' range='[3.3.401.R36_v20100727-0110,3.3.401.R36_v20100727-0110]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.help.appserver' range='[3.1.400.v20100427,3.1.400.v20100427]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='com.adobe.flexbuilder.services.WEBService.derived' range='[4.5.0.308971,4.5.0.308971]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.rcp_root' range='[3.6.1.r361_v20100827-9OArFLdFjY-ThSQXmKvKz0_T,3.6.1.r361_v20100827-9OArFLdFjY-ThSQXmKvKz0_T]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ui.cheatsheets' range='[3.4.0.v20100427,3.4.0.v20100427]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='com.ibm.icu' range='[4.2.1.v20100412,4.2.1.v20100412]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.net.win32.x86' range='[1.0.100.I20100511-0800,1.0.100.I20100511-0800]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.jdt.doc.user' range='[3.6.1.r361_v20100721-0800,3.6.1.r361_v20100721-0800]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.wst.dtdeditor.doc.user' range='[1.0.600.v201005192212,1.0.600.v201005192212]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ui.net' range='[1.2.100.I20100505-1245,1.2.100.I20100505-1245]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.app' range='[1.3.1.R36x_v20100803,1.3.1.R36x_v20100803]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.rcp.configuration_root.win32.win32.x86' range='[1.0.0.M20100909-0800,1.0.0.M20100909-0800]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.team.ui' range='[3.5.101.R36x_v20100825-0800,3.5.101.R36x_v20100825-0800]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.commands' range='[3.6.0.I20100512-1500,3.6.0.I20100512-1500]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='com.adobe.flexbuilder.as.editor' range='[4.5.0.308971,4.5.0.308971]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.security' range='[1.0.200.v20100503,1.0.200.v20100503]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='com.adobe.flexbuilder.crimson' range='[4.5.0.308971,4.5.0.308971]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.emf.ecore' range='[2.6.1.v20100914-1218,2.6.1.v20100914-1218]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.help.ui' range='[3.5.2.r36_v20100702,3.5.2.r36_v20100702]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='com.adobe.flexbuilder.services.CFService' range='[4.5.0.308971,4.5.0.308971]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.apache.xmlrpc' range='[3.0.0.v20100427-1100,3.0.0.v20100427-1100]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.mylyn.context_feature.feature.jar' range='[3.4.2.v20100916-0100-e3x-777718s73533L3L135331,3.4.2.v20100916-0100-e3x-777718s73533L3L135331]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='com.adobe.flexide.communityhelp' range='[4.5.0.308971,4.5.0.308971]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='com.adobe.flexbuilder.debug.ui.nl1' range='[4.5.0.308971,4.5.0.308971]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='com.adobe.flexide.feature.nl1.feature.group' range='[4.5.0.308971,4.5.0.308971]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.mylyn.discovery.core' range='[3.4.0.v20100608-0100-e3x,3.4.0.v20100608-0100-e3x]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.mylyn.tasks.search' range='[3.4.0.v20100608-0100-e3x,3.4.0.v20100608-0100-e3x]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.wst.xml_ui.feature.feature.group' range='[3.2.2.v201008170029-7H7AFUQDxumQGOpBqffOY2f1qxDZ,3.2.2.v201008170029-7H7AFUQDxumQGOpBqffOY2f1qxDZ]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='com.adobe.flexide.css.core' range='[4.5.0.308971,4.5.0.308971]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.mylyn.context.ui' range='[3.4.1.v20100909-0100-e3x,3.4.1.v20100909-0100-e3x]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.mylyn.discovery.ui' range='[3.4.0.v20100608-0100-e3x,3.4.0.v20100608-0100-e3x]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.event' range='[1.2.0.v20100503,1.2.0.v20100503]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.mylyn.wikitext.confluence.ui' range='[1.3.0.v20100608-0100-e3x,1.3.0.v20100608-0100-e3x]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.epp.mpc.ui' range='[1.0.1.v20100826-2143,1.0.1.v20100826-2143]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.jdt_root' range='[3.6.1.r361_v20100714-0800-7z8XFUSFLFlmgLc5z-Bvrt8-HVkH,3.6.1.r361_v20100714-0800-7z8XFUSFLFlmgLc5z-Bvrt8-HVkH]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='com.adobe.flexide.exportimport.nl1' range='[4.5.0.308971,4.5.0.308971]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='com.adobe.flexide.externaleditors.nl1' range='[4.5.0.308971,4.5.0.308971]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.emf.common' range='[2.6.0.v20100914-1218,2.6.0.v20100914-1218]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.wst.validation.infopop' range='[1.0.300.v200806041506,1.0.300.v200806041506]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.apache.commons.codec' range='[1.3.0.v20100106-1700,1.3.0.v20100106-1700]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.apache.commons.codec' range='[1.3.0.v20100518-1140,1.3.0.v20100518-1140]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.filebuffers' range='[3.5.100.v20100520-0800,3.5.100.v20100520-0800]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='com.adobe.flashbuilder.project.multiplatform.ui.nl1' range='[4.5.0.308971,4.5.0.308971]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.jsch.ui' range='[1.1.300.I20100505-1245,1.1.300.I20100505-1245]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ecf.provider.filetransfer' range='[3.1.0.v20100529-0735,3.1.0.v20100529-0735]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='com.adobe.flexbuilder.feature.core.nl1.feature.group' range='[4.5.0.308971,4.5.0.308971]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='com.adobe.flexbuilder.monitors.network.nl1' range='[4.5.0.308971,4.5.0.308971]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.registry' range='[3.5.0.v20100503,3.5.0.v20100503]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.update.ui' range='[3.2.300.v20100512,3.2.300.v20100512]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='com.adobe.model.feature.core.feature.jar' range='[4.5.304901.v20110217,4.5.304901.v20110217]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ui.console' range='[3.5.0.v20100526,3.5.0.v20100526]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.swt' range='[3.6.1.v3655c,3.6.1.v3655c]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.mylyn.ide_feature.feature.jar' range='[3.4.2.v20100916-0100-e3x-7G7J2BgJ9E99jDd49E994,3.4.2.v20100916-0100-e3x-7G7J2BgJ9E99jDd49E994]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.touchpoint.natives' range='[1.0.200.v20100503a,1.0.200.v20100503a]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.mylyn.wikitext.help.ui' range='[1.3.0.v20100608-0100-e3x,1.3.0.v20100608-0100-e3x]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='com.adobe.flexbuilder.editorcore.nl1' range='[4.5.0.308971,4.5.0.308971]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.frameworkadmin.equinox' range='[1.0.200.v20100505,1.0.200.v20100505]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='com.adobe.flashbuilder.multiplatform.ios.ui.nl1' range='[4.5.0.308971,4.5.0.308971]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.sat4j.pb' range='[2.2.0.v20100429,2.2.0.v20100429]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.hamcrest.core' range='[1.1.0.v20090501071000,1.1.0.v20090501071000]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='com.adobe.flexide.refactoring.core' range='[4.5.0.308971,4.5.0.308971]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.wst.validation.ui' range='[1.2.204.v201004150700,1.2.204.v201004150700]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='com.adobe.flexbuilder.tengine.nl1' range='[4.5.0.308971,4.5.0.308971]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='tooling.source.default' range='[1.0.0,1.0.0]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.databinding.property' range='[1.3.0.I20100601-0800,1.3.0.I20100601-0800]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.mylyn.commons.core' range='[3.4.0.v20100608-0100-e3x,3.4.0.v20100608-0100-e3x]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.databinding' range='[1.3.100.I20100601-0800,1.3.100.I20100601-0800]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.wst.common.ui' range='[1.1.500.v200911190730,1.1.500.v200911190730]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='com.adobe.flash.profiler' range='[4.5.0.308971,4.5.0.308971]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.concurrent' range='[1.0.100.v20100503,1.0.100.v20100503]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='toolingepp.package.java.ini.win32.win32.x86' range='[1.3.1.20100916-1202,1.3.1.20100916-1202]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='com.adobe.flexide.playerview' range='[4.5.0.308971,4.5.0.308971]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='com.adobe.flexide.as.core' range='[4.5.0.308971,4.5.0.308971]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.http.servlet' range='[1.1.0.v20100503,1.1.0.v20100503]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='com.adobe.flexbuilder.project.ui.nl1' range='[4.5.0.308971,4.5.0.308971]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.ql' range='[2.0.0.v20100503a,2.0.0.v20100503a]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.jface' range='[3.6.1.M20100825-0800,3.6.1.M20100825-0800]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='com.adobe.rds.feature.feature.group' range='[4.5.304901.v20110217,4.5.304901.v20110217]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='com.adobe.flexbuilder.as.editor.nl1' range='[4.5.0.308971,4.5.0.308971]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='com.adobe.flexbuilder.services.BlazeDSService' range='[4.5.0.308971,4.5.0.308971]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.jface.databinding' range='[1.4.0.I20100601-0800,1.4.0.I20100601-0800]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.wst.common_ui.feature.feature.group' range='[3.2.2.v201008091400-7C78FPhEdhO_mXde7kbap_K7X1Qt,3.2.2.v201008091400-7C78FPhEdhO_mXde7kbap_K7X1Qt]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.platform_root' range='[3.6.1.r361_v20100909-9gF78GrkFqw7GrsZnvz0JWNTeb6fue6896L,3.6.1.r361_v20100909-9gF78GrkFqw7GrsZnvz0JWNTeb6fue6896L]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.emf.edit' range='[2.6.0.v20100914-1218,2.6.0.v20100914-1218]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ui.browser' range='[3.3.0.v20100517,3.3.0.v20100517]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ui' range='[3.6.1.M20100826-1330,3.6.1.M20100826-1330]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='com.adobe.model.core' range='[4.5.304901.v20110217,4.5.304901.v20110217]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='com.adobe.flexide.utils.feature.feature.group' range='[4.5.0.308971,4.5.0.308971]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='com.adobe.flexbuilder.mxml.editor.nl1' range='[4.5.0.308971,4.5.0.308971]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.mylyn.team_feature.feature.jar' range='[3.4.2.v20100916-0100-e3x-4317w31211A1A012110,3.4.2.v20100916-0100-e3x-4317w31211A1A012110]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='com.adobe.flexbuilder.css.editor.nl1' range='[4.5.0.308971,4.5.0.308971]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.databinding.beans' range='[1.2.100.I20100601-0800,1.2.100.I20100601-0800]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.mylyn' range='[3.4.0.v20100608-0100-e3x,3.4.0.v20100608-0100-e3x]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.wst.common.modulecore.ui' range='[1.0.2.v201009010400,1.0.2.v201009010400]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.jdt.feature.group' range='[3.6.1.r361_v20100714-0800-7z8XFUSFLFlmgLc5z-Bvrt8-HVkH,3.6.1.r361_v20100714-0800-7z8XFUSFLFlmgLc5z-Bvrt8-HVkH]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.search' range='[3.6.0.v20100520-0800,3.6.0.v20100520-0800]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.emf.common.ui' range='[2.6.0.v20100914-1218,2.6.0.v20100914-1218]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.jsp.jasper.registry' range='[1.0.200.v20100503,1.0.200.v20100503]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.jdt.debug' range='[3.6.1.v20100715_r361,3.6.1.v20100715_r361]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.update.core.win32' range='[3.2.200.v20100512,3.2.200.v20100512]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='com.adobe.flexbuilder.feature.core.feature.jar' range='[4.5.0.308971,4.5.0.308971]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.mylyn_feature.feature.jar' range='[3.4.2.v20100916-0100-e3x-7Z7f77FBBoPbPQeUoFeZXJ8,3.4.2.v20100916-0100-e3x-7Z7f77FBBoPbPQeUoFeZXJ8]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.platform.feature.group' range='[3.6.1.r361_v20100909-9gF78GrkFqw7GrsZnvz0JWNTeb6fue6896L,3.6.1.r361_v20100909-9gF78GrkFqw7GrsZnvz0JWNTeb6fue6896L]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.platform.ide' range='[3.6.1.M20100909-0800,3.6.1.M20100909-0800]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.wst.xml_core.feature.feature.jar' range='[3.2.2.v201008170029-7C7OFXYF7RZHQHI5PyJwPT,3.2.2.v201008170029-7C7OFXYF7RZHQHI5PyJwPT]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='com.adobe.flashbuilder.launching.multiplatform.ui' range='[4.5.0.308971,4.5.0.308971]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.mylyn.resources.ui' range='[3.4.1.v20100909-0100-e3x,3.4.1.v20100909-0100-e3x]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='toolingwin32.win32.x86org.eclipse.update.configurator' range='[3.6.1.M20100909-0800,3.6.1.M20100909-0800]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.contenttype' range='[3.4.100.v20100505-1235,3.4.100.v20100505-1235]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.security.win32.x86' range='[1.0.200.v20100503,1.0.200.v20100503]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='com.adobe.flexide.feature.nl1.feature.jar' range='[4.5.0.308971,4.5.0.308971]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='com.adobe.flexbuilder.launching.ui.nl1' range='[4.5.0.308971,4.5.0.308971]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.platform.feature.jar' range='[3.6.1.r361_v20100909-9gF78GrkFqw7GrsZnvz0JWNTeb6fue6896L,3.6.1.r361_v20100909-9gF78GrkFqw7GrsZnvz0JWNTeb6fue6896L]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.wst.dtd.ui.infopop' range='[1.0.300.v200805140200,1.0.300.v200805140200]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.resources' range='[3.6.0.R36x_v20100825-0600,3.6.0.R36x_v20100825-0600]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.ui.sdk' range='[1.0.100.v20100513,1.0.100.v20100513]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ui.externaltools' range='[3.2.0.v20100427,3.2.0.v20100427]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.cvs' range='[1.0.500.v201009090800,1.0.500.v201009090800]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.resources.win32.x86' range='[3.5.100.v20100505-1345,3.5.100.v20100505-1345]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.repository' range='[2.0.1.R36x_v20100823,2.0.1.R36x_v20100823]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='com.adobe.flashbuilder.project.multiplatform.ui' range='[4.5.0.308971,4.5.0.308971]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.databinding.observable' range='[1.3.0.I20100601-0800,1.3.0.I20100601-0800]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ui.editors' range='[3.6.1.r361_v20100825-0800,3.6.1.r361_v20100825-0800]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.jdt.feature.jar' range='[3.6.1.r361_v20100714-0800-7z8XFUSFLFlmgLc5z-Bvrt8-HVkH,3.6.1.r361_v20100714-0800-7z8XFUSFLFlmgLc5z-Bvrt8-HVkH]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.jdt.apt.ui' range='[3.3.300.v20100513-0845,3.3.300.v20100513-0845]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ui.presentations.r21' range='[3.2.200.I20100517-1500,3.2.200.I20100517-1500]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='com.adobe.flexide.project.multiplatform' range='[4.5.0.308971,4.5.0.308971]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='com.adobe.flexide.embeddedplayer' range='[4.5.0.308971,4.5.0.308971]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.jobs' range='[3.5.1.R36x_v20100824,3.5.1.R36x_v20100824]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.security.ui' range='[1.0.200.v20100503,1.0.200.v20100503]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='com.adobe.flexide.css.core.nl1' range='[4.5.0.308971,4.5.0.308971]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.update.configurator' range='[3.3.100.v20100512,3.3.100.v20100512]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.wst.xml_ui.feature.feature.jar' range='[3.2.2.v201008170029-7H7AFUQDxumQGOpBqffOY2f1qxDZ,3.2.2.v201008170029-7H7AFUQDxumQGOpBqffOY2f1qxDZ]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.apache.lucene.analysis' range='[1.9.1.v20100518-1140,1.9.1.v20100518-1140]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.mylyn.wikitext_feature.feature.group' range='[1.3.2.v20100916-0100-e3x-7F7e1FC7sReRSnX-DReRRD,1.3.2.v20100916-0100-e3x-7F7e1FC7sReRSnX-DReRRD]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.emf.ecore.xmi' range='[2.5.0.v20100521-1846,2.5.0.v20100521-1846]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='toolingorg.eclipse.platform.ide.config.win32.win32.x86' range='[3.6.1.M20100909-0800,3.6.1.M20100909-0800]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='com.adobe.flexbuilder.services.J2EEService.nl1' range='[4.5.0.308971,4.5.0.308971]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='com.adobe.flexbuilder.services.HTTPService.nl1' range='[4.5.0.308971,4.5.0.308971]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.apache.lucene' range='[1.9.1.v20100518-1140,1.9.1.v20100518-1140]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='com.adobe.flexide.multiplatform.android.nl1' range='[4.5.0.308971,4.5.0.308971]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.mylyn.team.cvs' range='[3.4.1.v20100909-0100-e3x,3.4.1.v20100909-0100-e3x]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='tooling.osgi.bundle.default' range='[1.0.0,1.0.0]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ecf.identity' range='[3.1.0.v20100529-0735,3.1.0.v20100529-0735]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='toolingwin32.win32.x86org.eclipse.equinox.event' range='[3.6.1.M20100909-0800,3.6.1.M20100909-0800]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.ui' range='[2.0.0.v20100518,2.0.0.v20100518]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='com.adobe.flexbuilder.services.PHPService' range='[4.5.0.308971,4.5.0.308971]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='com.adobe.flexbuilder.designview.nl1' range='[4.5.0.308971,4.5.0.308971]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ltk.core.refactoring' range='[3.5.100.v20100526-0800,3.5.100.v20100526-0800]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='toolingorg.eclipse.platform.ide.ini.win32.win32.x86' range='[3.6.1.M20100909-0800,3.6.1.M20100909-0800]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='com.adobe.flexide.editors.derived.e35' range='[4.5.0.308971,4.5.0.308971]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='com.adobe.flexide.launching.multiplatform' range='[4.5.0.308971,4.5.0.308971]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='com.adobe.flexbuilder.codemodel' range='[4.5.0.308971,4.5.0.308971]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.draw2d' range='[3.6.1.v20100913-2020,3.6.1.v20100913-2020]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.cvs_root' range='[1.2.0.v20100427-7B77FKt90GE5h0SBT5FV9A01911,1.2.0.v20100427-7B77FKt90GE5h0SBT5FV9A01911]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.ui.discovery' range='[1.0.0.v20100519,1.0.0.v20100519]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.mylyn.java.tasks' range='[3.4.0.v20100608-0100-e3x,3.4.0.v20100608-0100-e3x]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.epp.usagedata.recording' range='[1.3.0.R201005261100,1.3.0.R201005261100]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.runtime.compatibility.registry' range='[3.3.0.v20100520,3.3.0.v20100520]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.wst.standard.schemas' range='[1.0.300.v201004110600,1.0.300.v201004110600]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.mylyn.java.ui' range='[3.4.0.v20100608-0100-e3x,3.4.0.v20100608-0100-e3x]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.wst.common.emf' range='[1.2.1.v201008260500,1.2.1.v201008260500]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='com.adobe.flexide.mxml.core' range='[4.5.0.308971,4.5.0.308971]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.epp.usagedata.ui' range='[1.3.0.R201005261100,1.3.0.R201005261100]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.emf.ecore.edit' range='[2.6.0.v20100914-1218,2.6.0.v20100914-1218]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ltk.ui.refactoring' range='[3.5.0.v20100526-0800,3.5.0.v20100526-0800]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='toolingorg.eclipse.equinox.launcher.win32.win32.x86' range='[1.1.1.R36x_v20100810,1.1.1.R36x_v20100810]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='com.adobe.flexide.multiplatform.android' range='[4.5.0.308971,4.5.0.308971]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='toolingorg.eclipse.platform.ide.configuration' range='[3.6.1.M20100909-0800,3.6.1.M20100909-0800]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.compare' range='[3.5.100.I20100526-0800,3.5.100.I20100526-0800]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='toolingwin32.win32.x86org.eclipse.equinox.simpleconfigurator' range='[3.6.1.M20100909-0800,3.6.1.M20100909-0800]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.wst.xmleditor.doc.user' range='[1.0.700.v201005192212,1.0.700.v201005192212]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='com.adobe.flexide.as.core.nl1' range='[4.5.0.308971,4.5.0.308971]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='com.adobe.flexbuilder.exportimport.nl1' range='[4.5.0.308971,4.5.0.308971]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.extensionlocation' range='[1.2.0.v20100518,1.2.0.v20100518]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='com.adobe.flexide.launching.multiplatform.nl1' range='[4.5.0.308971,4.5.0.308971]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='com.adobe.flexbuilder.dcrad' range='[4.5.0.308971,4.5.0.308971]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.jdt.junit.core' range='[3.6.1.r361_v20100825-0800,3.6.1.r361_v20100825-0800]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.jdt.junit.runtime' range='[3.4.200.v20100526-0800,3.4.200.v20100526-0800]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='com.adobe.flexbuilder.json' range='[4.5.0.308971,4.5.0.308971]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.platform.doc.user' range='[3.6.1.r361_v20100825-0800,3.6.1.r361_v20100825-0800]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.simpleconfigurator' range='[1.0.200.v20100503,1.0.200.v20100503]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.mylyn.wikitext.ui' range='[1.3.0.v20100608-0100-e3x,1.3.0.v20100608-0100-e3x]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='com.adobe.flexbuilder.flashbridge' range='[4.5.0.308971,4.5.0.308971]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.mortbay.jetty.server' range='[6.1.23.v201004211559,6.1.23.v201004211559]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.epp.package.java' range='[1.3.1.20100913-1228,1.3.1.20100913-1228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.apache.xml.serializer' range='[2.7.1.v201005080400,2.7.1.v201005080400]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='com.adobe.flexbuilder.debug.ui' range='[4.5.0.308971,4.5.0.308971]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='com.adobe.flash.codemodel.osgi' range='[4.5.0.308971,4.5.0.308971]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.jdt.compiler.apt' range='[1.0.300.v20100513-0845,1.0.300.v20100513-0845]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='toolingepp.package.java.config.win32.win32.x86' range='[1.3.1.20100916-1202,1.3.1.20100916-1202]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.epp.package.java.feature.feature.jar' range='[1.3.1.20100916-1202,1.3.1.20100916-1202]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='com.adobe.flexbuilder.services.HTTPService' range='[4.5.0.308971,4.5.0.308971]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.mylyn.bugzilla.core' range='[3.4.2.v20100902-0100-e3x,3.4.2.v20100902-0100-e3x]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.repository.tools' range='[2.0.1.R36x_v20100823,2.0.1.R36x_v20100823]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='com.adobe.flexbuilder.standalone.nl1' range='[4.5.0.308971,4.5.0.308971]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.wst.xsd.core' range='[1.1.502.v201008201521,1.1.502.v201008201521]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='toolingwin32.win32.x86org.eclipse.core.runtime' range='[3.6.1.M20100909-0800,3.6.1.M20100909-0800]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.apache.commons.httpclient' range='[3.1.0.v20080605-1935,3.1.0.v20080605-1935]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.apache.commons.httpclient' range='[3.1.0.v201005080502,3.1.0.v201005080502]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ui.ide' range='[3.6.1.M20100825-0800,3.6.1.M20100825-0800]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.garbagecollector' range='[1.0.100.v20100503,1.0.100.v20100503]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='toolingwin32.win32.x86org.eclipse.equinox.common' range='[3.6.1.M20100909-0800,3.6.1.M20100909-0800]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.rcp.configuration.feature.group' range='[1.0.0.M20100909-0800,1.0.0.M20100909-0800]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='com.adobe.flexbuilder.importartwork.nl1' range='[4.5.0.308971,4.5.0.308971]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.mylyn.wikitext_feature.feature.jar' range='[1.3.2.v20100916-0100-e3x-7F7e1FC7sReRSnX-DReRRD,1.3.2.v20100916-0100-e3x-7F7e1FC7sReRSnX-DReRRD]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.apache.ant' range='[1.7.1.v20100518-1145,1.7.1.v20100518-1145]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.wst.xsd.ui' range='[1.2.303.v201004290328,1.2.303.v201004290328]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='com.adobe.rds.core' range='[4.5.304901.v20110217,4.5.304901.v20110217]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.jdt.junit' range='[3.6.1.r361_v20100825-0800,3.6.1.r361_v20100825-0800]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ecf.filetransfer' range='[4.0.0.v20100529-0735,4.0.0.v20100529-0735]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.mylyn.ide.ui' range='[3.4.0.v20100608-0100-e3x,3.4.0.v20100608-0100-e3x]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='com.adobe.flexbuilder.project.e35' range='[4.5.0.308971,4.5.0.308971]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.net' range='[1.2.100.I20100511-0800,1.2.100.I20100511-0800]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='com.adobe.flexbuilder.help.nl1' range='[4.5.0.308971,4.5.0.308971]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.mylyn.wikitext.twiki.ui' range='[1.3.0.v20100608-0100-e3x,1.3.0.v20100608-0100-e3x]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.mylyn_feature.feature.group' range='[3.4.2.v20100916-0100-e3x-7Z7f77FBBoPbPQeUoFeZXJ8,3.4.2.v20100916-0100-e3x-7Z7f77FBBoPbPQeUoFeZXJ8]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.xsd' range='[2.6.0.v20100914-1218,2.6.0.v20100914-1218]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.directorywatcher' range='[1.0.202.R36x_v20100727,1.0.202.R36x_v20100727]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='com.adobe.flexbuilder.codemodel.nl1' range='[4.5.0.308971,4.5.0.308971]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.http.registry' range='[1.1.0.v20100503,1.1.0.v20100503]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='com.adobe.flexbuilder.project.ui' range='[4.5.0.308971,4.5.0.308971]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.emf.ecore.change' range='[2.5.1.v20100907-1643,2.5.1.v20100907-1643]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.junit' range='[3.8.2.v3_8_2_v20100427-1100,3.8.2.v3_8_2_v20100427-1100]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.junit' range='[4.8.1.v4_8_1_v20100427-1100,4.8.1.v4_8_1_v20100427-1100]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.epp.usagedata.gathering' range='[1.3.0.R201005261100,1.3.0.R201005261100]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.launcher' range='[1.1.0.v20100507,1.1.0.v20100507]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ui.intro' range='[3.4.0.v20100427,3.4.0.v20100427]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.team.core' range='[3.5.100.R36x_v20100825-0800,3.5.100.R36x_v20100825-0800]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='com.adobe.flexbuilder.debug.e33' range='[4.5.0.308971,4.5.0.308971]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='toolingepp.package.java.configuration' range='[1.3.1.20100916-1202,1.3.1.20100916-1202]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.wst.xsdeditor.doc.user' range='[1.0.800.v201005192212,1.0.800.v201005192212]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.swt.win32.win32.x86' range='[3.6.1.v3655c,3.6.1.v3655c]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.osgi.services' range='[3.2.100.v20100503,3.2.100.v20100503]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.cvs.feature.jar' range='[1.2.0.v20100427-7B77FKt90GE5h0SBT5FV9A01911,1.2.0.v20100427-7B77FKt90GE5h0SBT5FV9A01911]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.wst.common.infopop' range='[1.0.300.v201004280700,1.0.300.v201004280700]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='com.adobe.flexbuilder.debug.ui.e36' range='[4.5.0.308971,4.5.0.308971]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.cvs.feature.group' range='[1.2.0.v20100427-7B77FKt90GE5h0SBT5FV9A01911,1.2.0.v20100427-7B77FKt90GE5h0SBT5FV9A01911]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='com.adobe.flexbuilder.ajaxbridge' range='[4.5.0.308971,4.5.0.308971]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.mylyn.ide.ant' range='[3.4.0.v20100608-0100-e3x,3.4.0.v20100608-0100-e3x]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.apache.jasper' range='[5.5.17.v201004212143,5.5.17.v201004212143]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='com.adobe.flexbuilder.exportimport' range='[4.5.0.308971,4.5.0.308971]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.discovery.feature.feature.jar' range='[1.0.0.v20100510-4--9oB5855K7P,1.0.0.v20100510-4--9oB5855K7P]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.ui.sdk.scheduler' range='[1.0.0.v20100507-1815,1.0.0.v20100507-1815]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='com.adobe.rds.dataview' range='[4.5.304901.v20110217,4.5.304901.v20110217]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.debug.core' range='[3.6.0.v20100519,3.6.0.v20100519]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='com.adobe.flashbuilder.multiplatform.android.ui' range='[4.5.0.308971,4.5.0.308971]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.wst.sse.doc.user' range='[1.1.100.v201005192212,1.1.100.v201005192212]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='com.adobe.flexide.fcproject.nl1' range='[4.5.0.308971,4.5.0.308971]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.epp.package.common.feature.feature.jar' range='[1.3.1.20100916-1202,1.3.1.20100916-1202]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.jdt.core.manipulation' range='[1.3.0.v20100520-0800,1.3.0.v20100520-0800]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='com.adobe.flexide.externaleditors' range='[4.5.0.308971,4.5.0.308971]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.update.scheduler' range='[3.2.300.v20100512,3.2.300.v20100512]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.osgi' range='[3.6.1.R36x_v20100806,3.6.1.R36x_v20100806]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='javax.xml' range='[1.3.4.v201005080400,1.3.4.v201005080400]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.mylyn.java_feature.feature.jar' range='[3.4.2.v20100916-0100-e3x-7D7F-AkF7B77V7c37B773,3.4.2.v20100916-0100-e3x-7D7F-AkF7B77V7c37B773]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='com.adobe.flexide.amt' range='[4.5.0.308971,4.5.0.308971]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='com.adobe.flexide.feature.feature.jar' range='[4.5.0.308971,4.5.0.308971]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ecf.ssl' range='[1.0.0.v20100529-0735,1.0.0.v20100529-0735]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ecf.provider.filetransfer.httpclient' range='[4.0.0.v20100529-0735,4.0.0.v20100529-0735]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.publisher' range='[1.1.2.v20100824-2220,1.1.2.v20100824-2220]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.jem.util' range='[2.1.2.v201008120100,2.1.2.v201008120100]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.user.ui.feature.group' range='[2.0.1.r361_v20100903-897HFZFFZRuSD2LMtVxyz0Vr,2.0.1.r361_v20100903-897HFZFFZRuSD2LMtVxyz0Vr]'/>
      </requires>
      <touchpoint id='null' version='0.0.0'/>
    </unit>
    <unit id='com.adobe.flexbuilder.feature.standalone.nl1.feature.group' version='4.5.0.308971' singleton='false'>
      <update id='com.adobe.flexbuilder.feature.standalone.nl1.feature.group' range='[0.0.0,4.5.0.308971)' severity='0'/>
      <properties size='7'>
        <property name='org.eclipse.equinox.p2.name' value='Adobe Flash Builder Localized Top Feature'/>
        <property name='org.eclipse.equinox.p2.description' value='%description'/>
        <property name='org.eclipse.equinox.p2.provider' value='Adobe Systems Incorporated'/>
        <property name='org.eclipse.equinox.p2.type.group' value='true'/>
        <property name='df_LT.license' value='Release Software License Agreements &#xA;http://www.adobe.com/go/eulas/'/>
        <property name='df_LT.description' value='Adobe Flash Builder.'/>
        <property name='df_LT.copyright' value='© 2004-2010 Adobe Systems Incorporated and its licensors. All Rights Reserved.&#xA;&#xA;Adobe, the Adobe logo, Flash, and Flash Builder are either registered trademarks or&#xA;trademarks of Adobe Systems Incorporated in the United States and/or other countries.&#xA;&#xA;Built on Eclipse is a trademark of the Eclipse Foundation, Inc.  Portions utilize &#xA;Microsoft Windows Media Technologies. Copyright 1999-2002 Microsoft Corporation. &#xA;All rights reserved.&#xA;&#xA;Updated Information/Additional Third Party Code Information available at&#xA;http://www.adobe.com/go/thirdparty'/>
      </properties>
      <provides size='2'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='com.adobe.flexbuilder.feature.standalone.nl1.feature.group' version='4.5.0.308971'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='5'>
        <required namespace='org.eclipse.equinox.p2.iu' name='com.adobe.flexbuilder.feature.core.nl1.feature.group' range='[4.5.0.308971,4.5.0.308971]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='com.adobe.flexbuilder.feature.standalone.feature.group' range='[4.5.0.308971,4.5.0.308971]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='com.adobe.flexbuilder.standalone' range='0.0.0'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='com.adobe.flexbuilder.standalone.nl1' range='[4.5.0.308971,4.5.0.308971]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='com.adobe.flexbuilder.feature.standalone.nl1.feature.jar' range='[4.5.0.308971,4.5.0.308971]'>
          <filter>
            (org.eclipse.update.install.features=true)
          </filter>
        </required>
      </requires>
      <touchpoint id='null' version='0.0.0'/>
      <licenses size='1'>
        <license uri='%25licenseURL' url='%25licenseURL'>
          %license
        </license>
      </licenses>
      <copyright>
        %copyright
      </copyright>
    </unit>
    <unit id='com.adobe.model.feature.core.feature.group' version='4.5.304901.v20110217' singleton='false'>
      <update id='com.adobe.model.feature.core.feature.group' range='[0.0.0,4.5.304901.v20110217)' severity='0'/>
      <properties size='9'>
        <property name='org.eclipse.equinox.p2.name' value='%featureName'/>
        <property name='org.eclipse.equinox.p2.description' value='%description'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.type.group' value='true'/>
        <property name='df_LT.license' value='ADOBE SYSTEMS INCORPORATED&#xA;&#xA;Adobe Application Modeling Plugin&#xA;&#xA;Software License Agreement&#xA;&#xA;NOTICE TO USER:  THIS LICENSE AGREEMENT (&quot;AGREEMENT&quot;) GOVERNS INSTALLATION AND USE BY LICENSEES OF THE ADOBE SOFTWARE DESCRIBED HEREIN.  LICENSEE AGREES THAT THIS AGREEMENT IS LIKE ANY WRITTEN NEGOTIATED AGREEMENT SIGNED BY LICENSEE.  BY CLICKING TO ACKNOWLEDGE AGREEMENT TO BE BOUND DURING REVIEW OF AN ELECTRONIC VERSION OF THIS LICENSE, OR DOWNLOADING, COPYING, INSTALLING OR USING THE SOFTWARE, LICENSEE ACCEPTS ALL THE TERMS AND CONDITIONS OF THIS AGREEMENT.  THIS AGREEMENT IS ENFORCEABLE AGAINST ANY PERSON OR ENTITY THAT INSTALLS AND USES THE SOFTWARE AND ANY PERSON OR ENTITY (E.G., SYSTEM INTEGRATOR, CONSULTANT OR CONTRACTOR) THAT INSTALLS OR USES THE SOFTWARE ON ANOTHER PERSON&apos;S OR ENTITY&apos;S BEHALF.&#xA;THIS agreement SHALL APPLY ONLY TO THE SOFTWARE to which Licensee has obtained a valid license REGARDLESS OF WHETHER OTHER SOFTWARE IS REFERRED TO OR DESCRIBED HEREIN.  &#xA;&#xA;LICENSEE&apos;S RIGHTS UNDER THIS AGREEMENT MAY BE SUBJECT TO ADDITIONAL TERMS AND CONDITIONS IN A SEPARATE WRITTEN AGREEMENT WITH ADOBE THAT SUPPLEMENTS OR SUPERSEDES ALL OR PORTIONS OF THIS AGREEMENT.&#xA;&#xA;1.&#x9;Definitions&#xA;1.1&#x9;&quot;Adobe&quot; means Adobe Systems Incorporated, a Delaware corporation, 345 Park Avenue, San Jose, California 95110, if subsection 9(a) of this Agreement applies; otherwise it means Adobe Systems Software Ireland Limited, 4-6 Riverwalk, Citywest Business Campus, Dublin 24, Ireland, a company organized under the laws of Ireland and an affiliate and licensee of Adobe Systems Incorporated.&#xA;1.2&#x9;&quot;Authorized Users&quot; means employees and individual contractors (i.e., temporary employees) of Licensee.&#xA;1.3&#x9;&quot;Computer&quot; means one or more central processing units (&quot;CPU&quot;) in a hardware device (including a Server) that accepts information in digital or similar form and manipulates it for a specific result based on a sequence of instructions.&#xA;1.4&#x9;&quot;Disaster Recovery Environment&quot; means Licensee&apos;s technical environment designed solely to allow Licensee to respond to an interruption in service due to an event beyond Licensee&apos;s control that creates an inability on Licensee&apos;s part to provide critical business functions for a material period of time.&#xA;1.6&#x9;&quot;Documentation&quot; means the user manuals and/or technical publications as applicable, supplied in connection with validly licensed Software relating to the installation, use and administration of the Software.&#xA;1.7&#x9;&quot;Internal Network&quot; means Licensee&apos;s private, proprietary network resource accessible only by Authorized Users.  &quot;Internal Network&quot; specifically excludes the Internet or any other network community open to the public, including membership or subscription driven groups, associations or similar organizations.  Connection by secure links such as VPN or dial up to Licensee&apos;s Internal Network for the purpose of allowing Authorized Users to use the Software should be deemed use over an Internal Network.&#xA;1.8&#x9;&quot;License Metric&quot; means each of the per-unit metrics specified by Adobe in connection with the licensed quantities identified in a separate writing to describe the scope of Licensee&apos;s right to use the Software. The License Metrics are incorporated by reference into this Agreement.  One or more of the following License Metrics (or another License Metric as provided in a separate writing) applies to each software application as further provided herein:&#xA;&#x9;(a)&#x9;&quot;Per-CPU&quot; The total number of CPUs on the Computers used to operate the Software may not exceed the licensed quantity of CPUs.  For purposes of this License Metric:  (i) all CPUs on a Computer on which the Software is installed shall be deemed to operate the Software unless Licensee configures that Computer (using a reliable and verifiable means of hardware or software partitioning) such that the total number of CPUs that actually operate the Software is less than the total number on that Computer; and, (ii) when a CPU contains more than one processing core, each group of two (2) processing cores, and any remaining unpaired processing core, will be deemed a CPU unless otherwise provided in the applicable Multicore Conversion Table available at http://www.adobe.com/go/multicorepolicy or as separately provided in writing.&#xA;&#x9;(b)&#x9;&quot;Per-Server&quot; The total number of Servers on which the Software is installed may not exceed the licensed quantity of Servers.&#xA;1.9&#x9;&quot;Server&quot; means a Computer designed or configured for access by multiple users through a network.&#xA;1.10&#x9;&quot;Software&quot; means the object code version of the validly licensed software program(s) including all Documentation and other materials provided by Adobe to Licensee under this Agreement, and any modified versions and copies of, and upgrades, updates and additions to such Software, provided to Licensee by Adobe at any time, to the extent not provided under a separate agreement. The term &quot;Software Product&quot; may also be used to indicate a particular product or version of a product, and otherwise has the same meaning as Software.&#xA;&#xA;2.&#x9;License.  Subject to the terms and conditions of this Agreement, Adobe grants to Licensee a perpetual (except as otherwise set forth in this Agreement), non-exclusive license to permit Authorized Users to install and use the Software delivered hereunder according to the terms and conditions of this Agreement on Computers within Licensee&apos;s Internal Network, on the licensed platforms and configurations, in the manner and for the purposes described in the Documentation, as further set forth below.  &#xA;2.1&#x9;Additional Software.  Licensee is not permitted to use any software applications or components accompanying or installed with the Software unless Licensee is validly licensed to do so and only to the extent explicitly permitted under this Agreement or a separate writing.  Use of some materials and services (including without limitation third party materials and services) included in or accessed through the Software may be subject to other terms and conditions typically found in a separate license agreement, terms of use or &quot;Read Me&quot; file located within or near such materials and services or at http://www.adobe.com/products/eula/third_party/.  Any licenses granted hereunder do not alter any rights and obligations Licensee may have under the terms and conditions governing such third party materials and services provided, however, that the disclaimer of warranty and limitation of liability provisions in this Agreement will apply to all Software provided hereunder.  By accessing and/or using any such other materials or services, Licensee hereby agrees to the applicable separate license agreements that apply to such other materials or services.&#xA;2.2&#x9;Backup and Disaster Recovery.   Licensee may make and install a reasonable number of copies of the Software for backup and archival purposes and use such copies solely in the event that the primary copy has failed or is destroyed, but in no event may Licensee use such copies concurrently with Production Software or Development Software.  Licensee may also install copies of the Software in a Disaster Recovery Environment for use solely in disaster recovery and not for production, development, evaluation or testing purposes other than to ensure that the Software is capable of replacing the primary usage of the Software in case of a disaster.&#xA;2.3&#x9;Documentation.  Licensee may make and distribute copies of the Documentation for use by Authorized Users in connection with use of the Software in accordance with this Agreement, but no more than the amount reasonably necessary.  Any permitted copy of the Documentation that Licensee makes must contain the same copyright and other proprietary notices that appear on or in the Documentation.&#xA;2.4&#x9;Outsourcing.  Licensee may sub-license use of the Software to a third party outsourcing or facilities management contractor to operate the Software on Licensee&apos;s behalf, provided that (a) Licensee provides Adobe with prior written notice; (b) Licensee is responsible for ensuring that any such contractor agrees to abide by and fully complies with the terms of this Agreement as they relate to the use of the Software on the same basis as applies to Licensee; (c) such use is only in relation to Licensee&apos;s direct beneficial business purposes as restricted herein; (d) such use does not represent or constitute an increase in the scope or number of licenses provided hereunder; and (e) Licensee shall remain fully liable for any and all acts or omissions by the contractor related to this Agreement.&#xA;2.5&#x9;Font Software.  If the Software includes font software, then Licensee may (a) use the font software on Licensee&apos;s Computers in connection with Licensee&apos;s use of the Software as permitted under this Agreement; (b) output such font software on any output devices connected to Licensee&apos;s Computers; (c) convert and install the font software into another format for use in other environments provided that use of the converted font software may not be distributed or transferred for any purpose except in accordance with the transfer section in this Agreement; and (d) embed copies of the font software into Licensee&apos;s electronic documents for the purpose of printing and viewing the document, provided that if the font software Licensee  is embedding is identified as  &quot;licensed for editable embeddingâ? on Adobe&apos;s website at http://www.adobe.com/type/browser/legal/embeddingeula.html, Licensee may also embed copies of that font software for the additional limited purpose of editing Licensee&apos;s electronic documents.  No other embedding rights are implied or permitted under this license.&#xA;2.6&#x9;Restrictions&#xA;2.6.1&#x9;No Modifications, No Reverse Engineering. Licensee shall not modify, port, adapt or translate the Software. Licensee shall not reverse engineer, decompile, disassemble or otherwise attempt to discover the source code of the Software.  Notwithstanding the foregoing, decompiling the Software is permitted to the extent the laws of Licensee&apos;s jurisdiction give Licensee the right to do so to obtain information necessary to render the Software interoperable with other software; provided, however, that Licensee must first request such information from Adobe and Adobe may, in its discretion, either provide such information to Licensee or impose reasonable conditions, including a reasonable fee, on such use of the source code to ensure that Adobe&apos;s and its suppliers&apos; proprietary rights in the source code for the Software are protected.&#xA;2.6.2&#x9;No Unbundling. The Software may include various applications, utilities and components, may support multiple platforms and languages or may be provided to Licensee on multiple media or in multiple copies. Nonetheless, the Software is designed and provided to Licensee as a single product to be used as a single product on Computers and platforms as permitted herein. Licensee is not required to use all component parts of the Software, but Licensee shall not unbundle the component parts of the Software for use on different Computers. Licensee shall not unbundle or repackage the Software for distribution, transfer or resale.&#xA;2.6.3&#x9;No Transfer.  Except as may be explicitly provided in this Agreement, Licensee shall not (i) sublicense, assign or transfer the Software or Licensee&apos;s rights in the Software, to any third party, or (ii) authorize any portion of the Software to be copied onto or accessed from another individual&apos;s or entity&apos;s Computer.    &#xA;2.6.4&#x9;Prohibited Use.  Except as expressly authorized under this Agreement, Licensee is prohibited from: (a) using the Software on behalf of third parties; (b) renting, leasing, lending or granting other rights in the Software including rights on a membership or subscription basis; (c) providing use of the Software in a computer service business, third party outsourcing facility or service, service bureau arrangement, network, or time sharing basis; and/or (d) using any component, library, or other technology included with the Software other than solely in connection with its use of the Software.&#xA;2.6.5&#x9;Export Rules. Licensee agrees that the Software will not be shipped, transferred or exported into any country or used in any manner prohibited by the United States Export Administration Act or any other export laws, restrictions or regulations (collectively the &quot;Export Laws&quot;). In addition, if the Software is identified as an export controlled item under the Export Laws, Licensee represents and warrants that Licensee is not a citizen of, or located within, an embargoed or otherwise restricted nation (including Iran, Iraq, Syria, Sudan, Libya, Cuba and North Korea) and that Licensee is not otherwise prohibited under the Export Laws from receiving the Software.   All rights to install and use the Software are granted on condition that such rights are forfeited if Licensee fails to comply with the terms of this Agreement.&#xA;2.6.6&#x9;Further Limitations. The Software must be used in conjunction with LiveCycle Data Services and Adobe Flash Builder 4.  Therefore, Licensee may only use Software in accordance with the License Metrics it has obtained for LiveCycle Data Services and/or Adobe Flash Builder 4.&#xA;2.7&#x9;Delivery. The Software may be delivered via electronic delivery or via tangible media (e.g., CD or DVD), and, if applicable, the Software may be supplied with a valid License Key.&#xA;&#xA;3.&#x9;Intellectual Property Rights. The Software and any copies that Licensee is authorized by Adobe to make are the intellectual property of and are owned by Adobe Systems Incorporated and its suppliers. The structure, organization and code of the Software are the valuable trade secrets and confidential information of Adobe Systems Incorporated and its suppliers. The Software is protected by copyright, including without limitation by United States Copyright Law, international treaty provisions and applicable laws in the country in which it is being used.  Except as expressly stated herein, this Agreement does not grant Licensee any intellectual property rights in the Software and all rights not expressly granted are reserved by Adobe.&#xA;&#xA;4.&#x9;Updates. If the Software is an upgrade or update to a previous version of the Software, Licensee must possess a valid license to such previous version in order to use such upgrade or update. All upgrades and updates are provided to Licensee subject to the terms of this Agreement on a license exchange basis. Licensee agrees that by using an upgrade or update Licensee voluntarily terminates Licensee&apos;s right to use any previous version of the Software. As an exception, Licensee may maintain installations of previous versions of the Software on Licensee&apos;s Computers for a reasonable period of time (but not exceeding ninety (90) days) after Licensee obtains the upgrade or update to assist Licensee in the transition to the upgrade or update, provided that Licensee&apos;s right to such simultaneous installations does not constitute an increase in the number of copies, licensed amounts or scope of use granted to Licensee hereunder. &#xA;&#xA;5.&#x9;WARRANTY&#xA;5.1&#x9;Warranty.  Except as may be otherwise provided in Section 12, Adobe warrants to Licensee that the Software will perform substantially in accordance with the Documentation for the ninety (90) day period following shipment of the Software when used on the recommended operating system, platform and hardware configuration. Non-substantial variation of performance from the Documentation does not establish a warranty right.  THIS LIMITED WARRANTY DOES NOT APPLY TO EVALUATION SOFTWARE, PRE-RELEASE SOFTWARE, PATCHES, Sample Code, font software converted into other formats, or to software that has been altered by Licensee, to the extent such alterations caused a defect.  All warranty claims must be made within such ninety (90) day period.  If the Software does not perform substantially as warranted above, the entire liability of Adobe and its affiliates and Licensee&apos;s exclusive remedy shall be limited to either, at Adobe&apos;s option, replacement of the Software or refund of the license fee paid to Adobe for the Software whereupon the license to such software shall automatically terminate.  THE LIMITED WARRANTY SET FORTH IN THIS SECTION GIVES LICENSEE SPECIFIC LEGAL RIGHTS. LICENSEE MAY HAVE ADDITIONAL RIGHTS WHICH VARY FROM JURISDICTION TO JURISDICTION.&#xA;5.2&#x9;DISCLAIMER. THE FOREGOING LIMITED WARRANTY IS THE ONLY WARRANTY MADE BY ADOBE AND ITS AFFILIATES AND STATES THE SOLE AND EXCLUSIVE REMEDIES FOR ADOBE, ITS AFFILIATES OR ITS SUPPLIERS&apos; BREACH OF WARRANTY.  EXCEPT FOR THE FOREGOING LIMITED WARRANTY, AND ANY WARRANTY, CONDITION, REPRESENTATION OR TERM TO THE EXTENT THE SAME CANNOT OR MAY NOT BE EXCLUDED OR LIMITED BY LAW APPLICABLE TO LICENSEE&apos;S JURISDICTION, ADOBE AND ITS AFFILIATES AND SUPPLIERS PROVIDE THE SOFTWARE AS-IS AND WITH ALL FAULTS AND EXPRESSLY DISCLAIM ALL OTHER WARRANTIES, CONDITIONS, REPRESENTATIONS OR TERMS, EXPRESS OR IMPLIED, WHETHER BY STATUTE, COMMON LAW, CUSTOM, USAGE OR OTHERWISE AS TO ANY MATTER, INCLUDING BUT NOT LIMITED TO PERFORMANCE, SECURITY, NON-INFRINGEMENT OF THIRD PARTY RIGHTS, INTEGRATION, MERCHANTABILITY, QUIET ENJOYMENT, SATISFACTORY QUALITY OR FITNESS FOR ANY PARTICULAR PURPOSE.  THIS DISCLAIMER OF WARRANTY MAY NOT BE VALID IN SOME JURISDICTIONS.  The provisions of Section 5.2 and Section 6 will survive the termination of this agreement, howsoever caused, but this will not imply or create any continued right to use the Software after termination of this Agreement.&#xA;&#xA;6.&#x9;LIMITATION OF LIABILITY. EXCEPT FOR THE EXCLUSIVE REMEDY SET FORTH ABOVE AND AS OTHERWISE PROVIDED IN SECTION 12, IN NO EVENT WILL ADOBE OR ITS AFFILIATES OR SUPPLIERS BE LIABLE TO LICENSEE FOR ANY LOSS, DAMAGES, CLAIMS OR COSTS WHATSOEVER INCLUDING ANY CONSEQUENTIAL, INDIRECT OR INCIDENTAL DAMAGES, ANY LOST PROFITS OR LOST SAVINGS, ANY DAMAGES RESULTING FROM BUSINESS INTERRUPTION, PERSONAL INJURY OR FAILURE TO MEET ANY DUTY OF CARE, OR CLAIMS BY A THIRD PARTY EVEN IF AN ADOBE REPRESENTATIVE HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH LOSS, DAMAGES, CLAIMS OR COSTS.  THE FOREGOING LIMITATIONS AND EXCLUSIONS APPLY TO THE EXTENT PERMITTED BY APPLICABLE LAW IN LICENSEE&apos;S JURISDICTION.  ADOBE&apos;S AGGREGATE LIABILITY AND THAT OF ITS AFFILIATES AND SUPPLIERS UNDER OR IN CONNECTION WITH THIS AGREEMENT WILL BE LIMITED TO THE AMOUNT PAID FOR THE SOFTWARE, IF ANY.  THIS LIMITATION WILL APPLY EVEN IN THE EVENT OF A FUNDAMENTAL OR MATERIAL BREACH OR A BREACH OF THE FUNDAMENTAL OR MATERIAL TERMS OF THIS AGREEMENT. THIS LIMITATION OF LIABILITY MAY NOT BE VALID IN SOME STATES.  Nothing contained in this Agreement limits Adobe&apos;s liability to Licensee in the event of death or personal injury resulting from Adobe&apos;s negligence or for the tort of deceit (fraud). Adobe is acting on behalf of its affiliates and suppliers for the purpose of disclaiming, excluding and limiting obligations, warranties and liability, but in no other respects and for no other purpose. For further information, please see the jurisdiction specific information at the end of this Agreement, if any, or contact Adobe&apos;s Customer Support Department.&#xA;&#xA;7.&#x9;Governing Law. This Agreement, each transaction entered into hereunder, and all matters arising from or related to this Agreement (including its validity and interpretation), will be governed and enforced by and construed in accordance with the substantive laws in force in: (a) the State of California, if a license to the Software is purchased when Licensee is in the United States, Canada, or Mexico; or (b) Japan, if a license to the Software is purchased when Licensee is in Japan, China, Korea, or other Southeast Asian country where all official languages are written in either an ideographic script (e.g., hanzi, kanji, or hanja), and/or other script based upon or similar in structure to an ideographic script, such as hangul or kana; or (c) England, if a license to the Software is purchased when Licensee is in any other jurisdiction not described above. The respective courts of Santa Clara County, California when California law applies, Tokyo District Court in Japan, when Japanese law applies, and the competent courts of London, England, when the law of England applies, shall each have non-exclusive jurisdiction over all disputes relating to this Agreement. This Agreement will not be governed by the conflict of law rules of any jurisdiction or the United Nations Convention on Contracts for the International Sale of Goods, the application of which is expressly excluded.&#xA;&#xA;8.&#x9;General Provisions. If any part of this Agreement is found void and unenforceable, it will not affect the validity of the balance of this Agreement, which shall remain valid and enforceable according to its terms.  Updates and upgrades may be licensed to Licensee by Adobe with additional or different terms.  The English version of this Agreement shall be the version used when interpreting or construing this Agreement.  This is the entire agreement between Adobe and Licensee relating to the Software and it supersedes any prior representations, discussions, undertakings, communications or advertising relating to the Software.&#xA;&#xA;9.&#x9;Notice to U.S. Government End Users.&#xA;9.1&#x9;Commercial Items.  The Software and Documentation are  &quot;Commercial Item(s),&quot; as that term is defined at 48 C.F.R. Section 2.101, consisting of  &quot;Commercial Computer Software&quot; and  &quot;Commercial Computer Software Documentation, &quot; as such terms are used in 48 C.F.R. Section 12.212 or 48 C.F.R. Section 227.7202, as applicable. Consistent with 48 C.F.R. Section 12.212 or 48 C.F.R. Sections 227.7202-1 through 227.7202-4, as applicable, the Commercial Computer Software and Commercial Computer Software Documentation are being licensed to U.S. Government end users (a) only as Commercial Items and (b) with only those rights as are granted to all other end users pursuant to the terms and conditions herein. Unpublished-rights reserved under the copyright laws of the United States. Adobe Systems Incorporated, 345 Park Avenue, San Jose, CA 95110-2704, USA.&#xA;9.2&#x9;U.S. Government Licensing of Adobe Technology. Licensee agrees that when licensing Adobe Software for acquisition by the U.S. Government, or any contractor therefore, Licensee will license consistent with the policies set forth in 48 C.F.R. Section 12.212 (for civilian agencies) and 48 C.F.R. Sections 227-7202-1 and 227-7202-4 (for the Department of Defense). For U.S. Government End Users, Adobe agrees to comply with all applicable equal opportunity laws including, if appropriate, the provisions of Executive Order 11246, as amended, Section 402 of the Vietnam Era Veterans Readjustment Assistance Act of 1974 (38 USC 4212), and Section 503 of the Rehabilitation Act of 1973, as amended, and the regulations at 41 CFR Parts 60-1 through 60-60, 60-250, and 60-741.  The affirmative action clause and regulations contained in the preceding sentence shall be incorporated by reference in this Agreement.&#xA;&#xA;10.&#x9;Compliance with Licenses.  Adobe may, at its expense, and no more than once every twelve (12) months, appoint an independent third party or Adobe&apos;s internal auditor to verify the usage and number of copies and installations of the Software in use by Licensee.  Any such verification shall be conducted upon no less than seven (7) business days notice, during regular business hours at Licensee&apos;s offices and shall not unreasonably interfere with Licensee&apos;s business activities.  Upon Licensee&apos;s request, both Adobe and its third party auditors, if applicable, shall execute a commercially reasonable non-disclosure agreement with Licensee before proceeding with the verification.  If such verification shows that Licensee is using a greater number of copies of the Software than that legitimately licensed, is exceeding any applicable License Metric, or is deploying or using the Software in any way not permitted under this Agreement and which would require additional license fees, Licensee shall pay the applicable fees for such additional usage rights or copies within thirty (30) days of invoice date, with such underpaid fees being the license fees as per Adobe&apos;s then-current, country specific, license fee list.  If underpaid fees are in excess of five percent (5%) of the value of the fees paid under this Agreement, then Licensee shall pay such underpaid fees and Adobe&apos;s reasonable costs of conducting the verification.  This Section shall survive expiration or termination of this Agreement for a period of two (2) years.&#xA;&#xA;11.&#x9;Confidentiality.  Licensee agrees that Licensee will treat the License Keys (&quot;Confidential Information&quot;) with the same degree of care to prevent unauthorized disclosure to anyone other than Authorized Users as Licensee accords to Licensee&apos;s own confidential information, but in no event less than reasonable care. Licensee may disclose the Confidential Information in response to a valid order by a court or other governmental body, when otherwise required by law, or when necessary to establish the rights of either party under this Agreement, provided Licensee gives Adobe advance written notice thereof.&#xA;&#xA;12.&#x9;Specific Provisions and Exceptions. This Section sets forth specific provisions related to certain components of the Software as well as limited exceptions to the above terms and conditions. To the extent that any provision in this Section is in conflict with any other term or condition in this agreement, this Section will supersede such other term or condition.&#xA;12.1&#x9;Limited Warranty for Users Residing in Germany or Austria. If Licensee obtained the Software in Germany or Austria, and Licensee usually resides in such country, then Section 7 does not apply; instead, Adobe warrants that the Software provides the functionalities set forth in the Documentation (the &quot;agreed upon functionalities&quot;) for the limited warranty period following receipt of the Software when used on the recommended operating system, platform and hardware configuration.  As used in this Section, &quot;limited warranty period&quot; means one (1) year if Licensee is a business user and two (2) years if Licensee is not a business user. Non-substantial variation from the agreed upon functionalities will not and does not establish any warranty rights. This limited warranty does not apply to SAMPLE CODE, PATCHES, FONT software converted into other formats, OR SOFTWARE THAT HAS BEEN ALTERED BY LICENSEE TO THE EXTENT SUCH ALTERATION CAUSED A DEFECT. To make a warranty claim, during the limited warranty period Licensee must return, at Adobe&apos;s expense, the Software and proof of purchase to the location where Licensee obtained it. If the functionalities of the Software vary substantially from the agreed upon functionalities, Adobe is entitled -- by way of re-performance and at its own discretion -- to repair or replace the Software. If this fails, Licensee is entitled to a reduction of the purchase price (reduction) or to cancel the purchase agreement (rescission). For further warranty information, please contact the Adobe Customer Support Department.&#xA;12.2&#x9;Limitation of Liability for Users Residing in Germany and Austria.&#xA;12.2.1&#x9;If Licensee obtained the Software in Germany or Austria, and Licensee usually resides in such country, then Section 8 does not apply. Instead, subject to the provisions in Section 12.2.2, Adobe and its affiliates&apos; statutory liability for damages will be limited as follows:  (i) Adobe and its affiliates will be liable only up to the amount of damages as typically foreseeable at the time of entering into the purchase agreement in respect of damages caused by a slightly negligent breach of a material contractual obligation and (ii) Adobe and its affiliates will not be liable for damages caused by a slightly negligent breach of a non-material contractual obligation.&#xA;12.2.2&#x9;The aforesaid limitation of liability will not apply to any mandatory statutory liability, in particular, to liability under the German Product Liability Act, liability for assuming a specific guarantee or liability for culpably caused personal injuries.&#xA;12.2.3&#x9;Licensee is required to take all reasonable measures to avoid and reduce damages, in particular to make back-up copies of the Software and Licensee&apos;s computer data subject to the provisions of this agreement.&#xA;&#xA;13.&#x9;Term and Termination. This Agreement shall remain in effect until any material breach of this Agreement by Licensee occurs, upon which this Agreement shall automatically terminate. Upon termination of this Agreement for any reason, Licensee shall discontinue use of the Software and shall destroy the Software, Documentation and all copies thereto. Termination shall not, however, relieve either party of obligations incurred prior to the termination. The following Sections shall survive termination of this Agreement: 1 (Definitions), 3 (Intellectual Property Rights), 5.2 (Disclaimer), 6 (Limitation of Liability), 7 (Governing Law), 8 (General Provisions), 9 (Notice to U.S. Government End Users), 11 (Confidentiality), 12 (Specific Provisions and Exceptions), 13 (Term and Termination) and 14 (Third-Party Beneficiary).&#xA;&#xA;14.&#x9;Third-Party Beneficiary. Licensee acknowledges and agrees that Adobe&apos;s licensors (and/or Adobe if Licensee obtained the Software from any party other than Adobe) are third party beneficiaries of this Agreement, with the right to enforce the obligations set forth herein with respect to the respective technology of such licensors and/or Adobe.&#xA;&#xA;15.&#x9;Pre-release Software Additional Terms. If the Software is pre-commercial release or beta software (&quot;Pre-release Softwareâ?), then this section applies. The Pre-release Software is a pre-release version, does not represent final product from Adobe, and may contain bugs, errors and other problems that could cause system or other failures and data loss. Adobe may never commercially release the Pre-release Software. If you received the Pre-release Software pursuant to a separate written agreement, such as the Adobe Systems Incorporated License Agreement for Pre-release Software, your use of the Software is also governed by such agreement. You will return or destroy all copies of Pre-release Software upon request by Adobe or upon Adobe&apos;s commercial release of such Software. YOUR USE OF PRE-RELEASE SOFTWARE IS AT YOUR OWN RISK. SEE SECTIONS 5 AND 6 FOR WARRANTY DISCLAIMERS AND LIABILITY LIMITATIONS WHICH GOVERN PRE-RELEASE SOFTWARE.&#xA;&#xA;If Licensee has any questions regarding this agreement or if Licensee wishes to request any information from Adobe please use the address and contact information included with this product to contact the Adobe office serving Licensee&apos;s jurisdiction.&#xA;&#xA;Adobe and LiveCycle are either registered trademarks or trademarks of Adobe Systems Incorporated in the United States and/or other countries.  All other trademarks are the property of their respective owners.&#xA;&#xA;&#xA;&#xA;Adobe Application Modeling Plugin EULA 092110'/>
        <property name='df_LT.description' value='Adobe Data Modeling Core Components'/>
        <property name='df_LT.providerName' value='Adobe Systems Incorporated'/>
        <property name='df_LT.featureName' value='Adobe Data Modeling Core Components'/>
        <property name='df_LT.copyright' value='(c) 2004-2010 Adobe Systems Incorporated and its licensors. All Rights Reserved.&#xA;&#xA;Adobe, the Adobe logo, Flash and Flash Builder are either registered trademarks or&#xA;trademarks of Adobe Systems Incorporated in the United States and/or other countries.&#xA;&#xA;Built on Eclipse is a trademark of the Eclipse foundation, Inc.  All other trademarks&#xA;are the property of their respective owners.&#xA;&#xA;Protected by U.S Patents. Patents Pending in the U.S and/or other countries.&#xA;&#xA;Third Party Software Notices and/or Additional Terms and Conditions found at&#xA;http://www.adobe.com/go/thirdparty'/>
      </properties>
      <provides size='2'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='com.adobe.model.feature.core.feature.group' version='4.5.304901.v20110217'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='6'>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.resources' range='0.0.0'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.runtime' range='0.0.0'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ui' range='0.0.0'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.expressions' range='0.0.0'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='com.adobe.model.core' range='[4.5.304901.v20110217,4.5.304901.v20110217]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='com.adobe.model.feature.core.feature.jar' range='[4.5.304901.v20110217,4.5.304901.v20110217]'>
          <filter>
            (org.eclipse.update.install.features=true)
          </filter>
        </required>
      </requires>
      <touchpoint id='null' version='0.0.0'/>
      <licenses size='1'>
        <license uri='%25licenseURL' url='%25licenseURL'>
          %license
        </license>
      </licenses>
      <copyright>
        %copyright
      </copyright>
    </unit>
    <unit id='com.adobe.rds.feature.feature.group' version='4.5.304901.v20110217' singleton='false'>
      <update id='com.adobe.rds.feature.feature.group' range='[0.0.0,4.5.304901.v20110217)' severity='0'/>
      <properties size='9'>
        <property name='org.eclipse.equinox.p2.name' value='%featureName'/>
        <property name='org.eclipse.equinox.p2.description' value='%description'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.type.group' value='true'/>
        <property name='df_LT.license' value='ADOBE SYSTEMS INCORPORATED&#xA;&#xA;Adobe Application Modeling Plugin&#xA;&#xA;Software License Agreement&#xA;&#xA;NOTICE TO USER:  THIS LICENSE AGREEMENT (&quot;AGREEMENT&quot;) GOVERNS INSTALLATION AND USE BY LICENSEES OF THE ADOBE SOFTWARE DESCRIBED HEREIN.  LICENSEE AGREES THAT THIS AGREEMENT IS LIKE ANY WRITTEN NEGOTIATED AGREEMENT SIGNED BY LICENSEE.  BY CLICKING TO ACKNOWLEDGE AGREEMENT TO BE BOUND DURING REVIEW OF AN ELECTRONIC VERSION OF THIS LICENSE, OR DOWNLOADING, COPYING, INSTALLING OR USING THE SOFTWARE, LICENSEE ACCEPTS ALL THE TERMS AND CONDITIONS OF THIS AGREEMENT.  THIS AGREEMENT IS ENFORCEABLE AGAINST ANY PERSON OR ENTITY THAT INSTALLS AND USES THE SOFTWARE AND ANY PERSON OR ENTITY (E.G., SYSTEM INTEGRATOR, CONSULTANT OR CONTRACTOR) THAT INSTALLS OR USES THE SOFTWARE ON ANOTHER PERSON&apos;S OR ENTITY&apos;S BEHALF.&#xA;THIS agreement SHALL APPLY ONLY TO THE SOFTWARE to which Licensee has obtained a valid license REGARDLESS OF WHETHER OTHER SOFTWARE IS REFERRED TO OR DESCRIBED HEREIN.  &#xA;&#xA;LICENSEE&apos;S RIGHTS UNDER THIS AGREEMENT MAY BE SUBJECT TO ADDITIONAL TERMS AND CONDITIONS IN A SEPARATE WRITTEN AGREEMENT WITH ADOBE THAT SUPPLEMENTS OR SUPERSEDES ALL OR PORTIONS OF THIS AGREEMENT.&#xA;&#xA;1.&#x9;Definitions&#xA;1.1&#x9;&quot;Adobe&quot; means Adobe Systems Incorporated, a Delaware corporation, 345 Park Avenue, San Jose, California 95110, if subsection 9(a) of this Agreement applies; otherwise it means Adobe Systems Software Ireland Limited, 4-6 Riverwalk, Citywest Business Campus, Dublin 24, Ireland, a company organized under the laws of Ireland and an affiliate and licensee of Adobe Systems Incorporated.&#xA;1.2&#x9;&quot;Authorized Users&quot; means employees and individual contractors (i.e., temporary employees) of Licensee.&#xA;1.3&#x9;&quot;Computer&quot; means one or more central processing units (&quot;CPU&quot;) in a hardware device (including a Server) that accepts information in digital or similar form and manipulates it for a specific result based on a sequence of instructions.&#xA;1.4&#x9;&quot;Disaster Recovery Environment&quot; means Licensee&apos;s technical environment designed solely to allow Licensee to respond to an interruption in service due to an event beyond Licensee&apos;s control that creates an inability on Licensee&apos;s part to provide critical business functions for a material period of time.&#xA;1.6&#x9;&quot;Documentation&quot; means the user manuals and/or technical publications as applicable, supplied in connection with validly licensed Software relating to the installation, use and administration of the Software.&#xA;1.7&#x9;&quot;Internal Network&quot; means Licensee&apos;s private, proprietary network resource accessible only by Authorized Users.  &quot;Internal Network&quot; specifically excludes the Internet or any other network community open to the public, including membership or subscription driven groups, associations or similar organizations.  Connection by secure links such as VPN or dial up to Licensee&apos;s Internal Network for the purpose of allowing Authorized Users to use the Software should be deemed use over an Internal Network.&#xA;1.8&#x9;&quot;License Metric&quot; means each of the per-unit metrics specified by Adobe in connection with the licensed quantities identified in a separate writing to describe the scope of Licensee&apos;s right to use the Software. The License Metrics are incorporated by reference into this Agreement.  One or more of the following License Metrics (or another License Metric as provided in a separate writing) applies to each software application as further provided herein:&#xA;&#x9;(a)&#x9;&quot;Per-CPU&quot; The total number of CPUs on the Computers used to operate the Software may not exceed the licensed quantity of CPUs.  For purposes of this License Metric:  (i) all CPUs on a Computer on which the Software is installed shall be deemed to operate the Software unless Licensee configures that Computer (using a reliable and verifiable means of hardware or software partitioning) such that the total number of CPUs that actually operate the Software is less than the total number on that Computer; and, (ii) when a CPU contains more than one processing core, each group of two (2) processing cores, and any remaining unpaired processing core, will be deemed a CPU unless otherwise provided in the applicable Multicore Conversion Table available at http://www.adobe.com/go/multicorepolicy or as separately provided in writing.&#xA;&#x9;(b)&#x9;&quot;Per-Server&quot; The total number of Servers on which the Software is installed may not exceed the licensed quantity of Servers.&#xA;1.9&#x9;&quot;Server&quot; means a Computer designed or configured for access by multiple users through a network.&#xA;1.10&#x9;&quot;Software&quot; means the object code version of the validly licensed software program(s) including all Documentation and other materials provided by Adobe to Licensee under this Agreement, and any modified versions and copies of, and upgrades, updates and additions to such Software, provided to Licensee by Adobe at any time, to the extent not provided under a separate agreement. The term &quot;Software Product&quot; may also be used to indicate a particular product or version of a product, and otherwise has the same meaning as Software.&#xA;&#xA;2.&#x9;License.  Subject to the terms and conditions of this Agreement, Adobe grants to Licensee a perpetual (except as otherwise set forth in this Agreement), non-exclusive license to permit Authorized Users to install and use the Software delivered hereunder according to the terms and conditions of this Agreement on Computers within Licensee&apos;s Internal Network, on the licensed platforms and configurations, in the manner and for the purposes described in the Documentation, as further set forth below.  &#xA;2.1&#x9;Additional Software.  Licensee is not permitted to use any software applications or components accompanying or installed with the Software unless Licensee is validly licensed to do so and only to the extent explicitly permitted under this Agreement or a separate writing.  Use of some materials and services (including without limitation third party materials and services) included in or accessed through the Software may be subject to other terms and conditions typically found in a separate license agreement, terms of use or &quot;Read Me&quot; file located within or near such materials and services or at http://www.adobe.com/products/eula/third_party/.  Any licenses granted hereunder do not alter any rights and obligations Licensee may have under the terms and conditions governing such third party materials and services provided, however, that the disclaimer of warranty and limitation of liability provisions in this Agreement will apply to all Software provided hereunder.  By accessing and/or using any such other materials or services, Licensee hereby agrees to the applicable separate license agreements that apply to such other materials or services.&#xA;2.2&#x9;Backup and Disaster Recovery.   Licensee may make and install a reasonable number of copies of the Software for backup and archival purposes and use such copies solely in the event that the primary copy has failed or is destroyed, but in no event may Licensee use such copies concurrently with Production Software or Development Software.  Licensee may also install copies of the Software in a Disaster Recovery Environment for use solely in disaster recovery and not for production, development, evaluation or testing purposes other than to ensure that the Software is capable of replacing the primary usage of the Software in case of a disaster.&#xA;2.3&#x9;Documentation.  Licensee may make and distribute copies of the Documentation for use by Authorized Users in connection with use of the Software in accordance with this Agreement, but no more than the amount reasonably necessary.  Any permitted copy of the Documentation that Licensee makes must contain the same copyright and other proprietary notices that appear on or in the Documentation.&#xA;2.4&#x9;Outsourcing.  Licensee may sub-license use of the Software to a third party outsourcing or facilities management contractor to operate the Software on Licensee&apos;s behalf, provided that (a) Licensee provides Adobe with prior written notice; (b) Licensee is responsible for ensuring that any such contractor agrees to abide by and fully complies with the terms of this Agreement as they relate to the use of the Software on the same basis as applies to Licensee; (c) such use is only in relation to Licensee&apos;s direct beneficial business purposes as restricted herein; (d) such use does not represent or constitute an increase in the scope or number of licenses provided hereunder; and (e) Licensee shall remain fully liable for any and all acts or omissions by the contractor related to this Agreement.&#xA;2.5&#x9;Font Software.  If the Software includes font software, then Licensee may (a) use the font software on Licensee&apos;s Computers in connection with Licensee&apos;s use of the Software as permitted under this Agreement; (b) output such font software on any output devices connected to Licensee&apos;s Computers; (c) convert and install the font software into another format for use in other environments provided that use of the converted font software may not be distributed or transferred for any purpose except in accordance with the transfer section in this Agreement; and (d) embed copies of the font software into Licensee&apos;s electronic documents for the purpose of printing and viewing the document, provided that if the font software Licensee  is embedding is identified as  &quot;licensed for editable embeddingâ? on Adobe&apos;s website at http://www.adobe.com/type/browser/legal/embeddingeula.html, Licensee may also embed copies of that font software for the additional limited purpose of editing Licensee&apos;s electronic documents.  No other embedding rights are implied or permitted under this license.&#xA;2.6&#x9;Restrictions&#xA;2.6.1&#x9;No Modifications, No Reverse Engineering. Licensee shall not modify, port, adapt or translate the Software. Licensee shall not reverse engineer, decompile, disassemble or otherwise attempt to discover the source code of the Software.  Notwithstanding the foregoing, decompiling the Software is permitted to the extent the laws of Licensee&apos;s jurisdiction give Licensee the right to do so to obtain information necessary to render the Software interoperable with other software; provided, however, that Licensee must first request such information from Adobe and Adobe may, in its discretion, either provide such information to Licensee or impose reasonable conditions, including a reasonable fee, on such use of the source code to ensure that Adobe&apos;s and its suppliers&apos; proprietary rights in the source code for the Software are protected.&#xA;2.6.2&#x9;No Unbundling. The Software may include various applications, utilities and components, may support multiple platforms and languages or may be provided to Licensee on multiple media or in multiple copies. Nonetheless, the Software is designed and provided to Licensee as a single product to be used as a single product on Computers and platforms as permitted herein. Licensee is not required to use all component parts of the Software, but Licensee shall not unbundle the component parts of the Software for use on different Computers. Licensee shall not unbundle or repackage the Software for distribution, transfer or resale.&#xA;2.6.3&#x9;No Transfer.  Except as may be explicitly provided in this Agreement, Licensee shall not (i) sublicense, assign or transfer the Software or Licensee&apos;s rights in the Software, to any third party, or (ii) authorize any portion of the Software to be copied onto or accessed from another individual&apos;s or entity&apos;s Computer.    &#xA;2.6.4&#x9;Prohibited Use.  Except as expressly authorized under this Agreement, Licensee is prohibited from: (a) using the Software on behalf of third parties; (b) renting, leasing, lending or granting other rights in the Software including rights on a membership or subscription basis; (c) providing use of the Software in a computer service business, third party outsourcing facility or service, service bureau arrangement, network, or time sharing basis; and/or (d) using any component, library, or other technology included with the Software other than solely in connection with its use of the Software.&#xA;2.6.5&#x9;Export Rules. Licensee agrees that the Software will not be shipped, transferred or exported into any country or used in any manner prohibited by the United States Export Administration Act or any other export laws, restrictions or regulations (collectively the &quot;Export Laws&quot;). In addition, if the Software is identified as an export controlled item under the Export Laws, Licensee represents and warrants that Licensee is not a citizen of, or located within, an embargoed or otherwise restricted nation (including Iran, Iraq, Syria, Sudan, Libya, Cuba and North Korea) and that Licensee is not otherwise prohibited under the Export Laws from receiving the Software.   All rights to install and use the Software are granted on condition that such rights are forfeited if Licensee fails to comply with the terms of this Agreement.&#xA;2.6.6&#x9;Further Limitations. The Software must be used in conjunction with LiveCycle Data Services and Adobe Flash Builder 4.  Therefore, Licensee may only use Software in accordance with the License Metrics it has obtained for LiveCycle Data Services and/or Adobe Flash Builder 4.&#xA;2.7&#x9;Delivery. The Software may be delivered via electronic delivery or via tangible media (e.g., CD or DVD), and, if applicable, the Software may be supplied with a valid License Key.&#xA;&#xA;3.&#x9;Intellectual Property Rights. The Software and any copies that Licensee is authorized by Adobe to make are the intellectual property of and are owned by Adobe Systems Incorporated and its suppliers. The structure, organization and code of the Software are the valuable trade secrets and confidential information of Adobe Systems Incorporated and its suppliers. The Software is protected by copyright, including without limitation by United States Copyright Law, international treaty provisions and applicable laws in the country in which it is being used.  Except as expressly stated herein, this Agreement does not grant Licensee any intellectual property rights in the Software and all rights not expressly granted are reserved by Adobe.&#xA;&#xA;4.&#x9;Updates. If the Software is an upgrade or update to a previous version of the Software, Licensee must possess a valid license to such previous version in order to use such upgrade or update. All upgrades and updates are provided to Licensee subject to the terms of this Agreement on a license exchange basis. Licensee agrees that by using an upgrade or update Licensee voluntarily terminates Licensee&apos;s right to use any previous version of the Software. As an exception, Licensee may maintain installations of previous versions of the Software on Licensee&apos;s Computers for a reasonable period of time (but not exceeding ninety (90) days) after Licensee obtains the upgrade or update to assist Licensee in the transition to the upgrade or update, provided that Licensee&apos;s right to such simultaneous installations does not constitute an increase in the number of copies, licensed amounts or scope of use granted to Licensee hereunder. &#xA;&#xA;5.&#x9;WARRANTY&#xA;5.1&#x9;Warranty.  Except as may be otherwise provided in Section 12, Adobe warrants to Licensee that the Software will perform substantially in accordance with the Documentation for the ninety (90) day period following shipment of the Software when used on the recommended operating system, platform and hardware configuration. Non-substantial variation of performance from the Documentation does not establish a warranty right.  THIS LIMITED WARRANTY DOES NOT APPLY TO EVALUATION SOFTWARE, PRE-RELEASE SOFTWARE, PATCHES, Sample Code, font software converted into other formats, or to software that has been altered by Licensee, to the extent such alterations caused a defect.  All warranty claims must be made within such ninety (90) day period.  If the Software does not perform substantially as warranted above, the entire liability of Adobe and its affiliates and Licensee&apos;s exclusive remedy shall be limited to either, at Adobe&apos;s option, replacement of the Software or refund of the license fee paid to Adobe for the Software whereupon the license to such software shall automatically terminate.  THE LIMITED WARRANTY SET FORTH IN THIS SECTION GIVES LICENSEE SPECIFIC LEGAL RIGHTS. LICENSEE MAY HAVE ADDITIONAL RIGHTS WHICH VARY FROM JURISDICTION TO JURISDICTION.&#xA;5.2&#x9;DISCLAIMER. THE FOREGOING LIMITED WARRANTY IS THE ONLY WARRANTY MADE BY ADOBE AND ITS AFFILIATES AND STATES THE SOLE AND EXCLUSIVE REMEDIES FOR ADOBE, ITS AFFILIATES OR ITS SUPPLIERS&apos; BREACH OF WARRANTY.  EXCEPT FOR THE FOREGOING LIMITED WARRANTY, AND ANY WARRANTY, CONDITION, REPRESENTATION OR TERM TO THE EXTENT THE SAME CANNOT OR MAY NOT BE EXCLUDED OR LIMITED BY LAW APPLICABLE TO LICENSEE&apos;S JURISDICTION, ADOBE AND ITS AFFILIATES AND SUPPLIERS PROVIDE THE SOFTWARE AS-IS AND WITH ALL FAULTS AND EXPRESSLY DISCLAIM ALL OTHER WARRANTIES, CONDITIONS, REPRESENTATIONS OR TERMS, EXPRESS OR IMPLIED, WHETHER BY STATUTE, COMMON LAW, CUSTOM, USAGE OR OTHERWISE AS TO ANY MATTER, INCLUDING BUT NOT LIMITED TO PERFORMANCE, SECURITY, NON-INFRINGEMENT OF THIRD PARTY RIGHTS, INTEGRATION, MERCHANTABILITY, QUIET ENJOYMENT, SATISFACTORY QUALITY OR FITNESS FOR ANY PARTICULAR PURPOSE.  THIS DISCLAIMER OF WARRANTY MAY NOT BE VALID IN SOME JURISDICTIONS.  The provisions of Section 5.2 and Section 6 will survive the termination of this agreement, howsoever caused, but this will not imply or create any continued right to use the Software after termination of this Agreement.&#xA;&#xA;6.&#x9;LIMITATION OF LIABILITY. EXCEPT FOR THE EXCLUSIVE REMEDY SET FORTH ABOVE AND AS OTHERWISE PROVIDED IN SECTION 12, IN NO EVENT WILL ADOBE OR ITS AFFILIATES OR SUPPLIERS BE LIABLE TO LICENSEE FOR ANY LOSS, DAMAGES, CLAIMS OR COSTS WHATSOEVER INCLUDING ANY CONSEQUENTIAL, INDIRECT OR INCIDENTAL DAMAGES, ANY LOST PROFITS OR LOST SAVINGS, ANY DAMAGES RESULTING FROM BUSINESS INTERRUPTION, PERSONAL INJURY OR FAILURE TO MEET ANY DUTY OF CARE, OR CLAIMS BY A THIRD PARTY EVEN IF AN ADOBE REPRESENTATIVE HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH LOSS, DAMAGES, CLAIMS OR COSTS.  THE FOREGOING LIMITATIONS AND EXCLUSIONS APPLY TO THE EXTENT PERMITTED BY APPLICABLE LAW IN LICENSEE&apos;S JURISDICTION.  ADOBE&apos;S AGGREGATE LIABILITY AND THAT OF ITS AFFILIATES AND SUPPLIERS UNDER OR IN CONNECTION WITH THIS AGREEMENT WILL BE LIMITED TO THE AMOUNT PAID FOR THE SOFTWARE, IF ANY.  THIS LIMITATION WILL APPLY EVEN IN THE EVENT OF A FUNDAMENTAL OR MATERIAL BREACH OR A BREACH OF THE FUNDAMENTAL OR MATERIAL TERMS OF THIS AGREEMENT. THIS LIMITATION OF LIABILITY MAY NOT BE VALID IN SOME STATES.  Nothing contained in this Agreement limits Adobe&apos;s liability to Licensee in the event of death or personal injury resulting from Adobe&apos;s negligence or for the tort of deceit (fraud). Adobe is acting on behalf of its affiliates and suppliers for the purpose of disclaiming, excluding and limiting obligations, warranties and liability, but in no other respects and for no other purpose. For further information, please see the jurisdiction specific information at the end of this Agreement, if any, or contact Adobe&apos;s Customer Support Department.&#xA;&#xA;7.&#x9;Governing Law. This Agreement, each transaction entered into hereunder, and all matters arising from or related to this Agreement (including its validity and interpretation), will be governed and enforced by and construed in accordance with the substantive laws in force in: (a) the State of California, if a license to the Software is purchased when Licensee is in the United States, Canada, or Mexico; or (b) Japan, if a license to the Software is purchased when Licensee is in Japan, China, Korea, or other Southeast Asian country where all official languages are written in either an ideographic script (e.g., hanzi, kanji, or hanja), and/or other script based upon or similar in structure to an ideographic script, such as hangul or kana; or (c) England, if a license to the Software is purchased when Licensee is in any other jurisdiction not described above. The respective courts of Santa Clara County, California when California law applies, Tokyo District Court in Japan, when Japanese law applies, and the competent courts of London, England, when the law of England applies, shall each have non-exclusive jurisdiction over all disputes relating to this Agreement. This Agreement will not be governed by the conflict of law rules of any jurisdiction or the United Nations Convention on Contracts for the International Sale of Goods, the application of which is expressly excluded.&#xA;&#xA;8.&#x9;General Provisions. If any part of this Agreement is found void and unenforceable, it will not affect the validity of the balance of this Agreement, which shall remain valid and enforceable according to its terms.  Updates and upgrades may be licensed to Licensee by Adobe with additional or different terms.  The English version of this Agreement shall be the version used when interpreting or construing this Agreement.  This is the entire agreement between Adobe and Licensee relating to the Software and it supersedes any prior representations, discussions, undertakings, communications or advertising relating to the Software.&#xA;&#xA;9.&#x9;Notice to U.S. Government End Users.&#xA;9.1&#x9;Commercial Items.  The Software and Documentation are  &quot;Commercial Item(s),&quot; as that term is defined at 48 C.F.R. Section 2.101, consisting of  &quot;Commercial Computer Software&quot; and  &quot;Commercial Computer Software Documentation, &quot; as such terms are used in 48 C.F.R. Section 12.212 or 48 C.F.R. Section 227.7202, as applicable. Consistent with 48 C.F.R. Section 12.212 or 48 C.F.R. Sections 227.7202-1 through 227.7202-4, as applicable, the Commercial Computer Software and Commercial Computer Software Documentation are being licensed to U.S. Government end users (a) only as Commercial Items and (b) with only those rights as are granted to all other end users pursuant to the terms and conditions herein. Unpublished-rights reserved under the copyright laws of the United States. Adobe Systems Incorporated, 345 Park Avenue, San Jose, CA 95110-2704, USA.&#xA;9.2&#x9;U.S. Government Licensing of Adobe Technology. Licensee agrees that when licensing Adobe Software for acquisition by the U.S. Government, or any contractor therefore, Licensee will license consistent with the policies set forth in 48 C.F.R. Section 12.212 (for civilian agencies) and 48 C.F.R. Sections 227-7202-1 and 227-7202-4 (for the Department of Defense). For U.S. Government End Users, Adobe agrees to comply with all applicable equal opportunity laws including, if appropriate, the provisions of Executive Order 11246, as amended, Section 402 of the Vietnam Era Veterans Readjustment Assistance Act of 1974 (38 USC 4212), and Section 503 of the Rehabilitation Act of 1973, as amended, and the regulations at 41 CFR Parts 60-1 through 60-60, 60-250, and 60-741.  The affirmative action clause and regulations contained in the preceding sentence shall be incorporated by reference in this Agreement.&#xA;&#xA;10.&#x9;Compliance with Licenses.  Adobe may, at its expense, and no more than once every twelve (12) months, appoint an independent third party or Adobe&apos;s internal auditor to verify the usage and number of copies and installations of the Software in use by Licensee.  Any such verification shall be conducted upon no less than seven (7) business days notice, during regular business hours at Licensee&apos;s offices and shall not unreasonably interfere with Licensee&apos;s business activities.  Upon Licensee&apos;s request, both Adobe and its third party auditors, if applicable, shall execute a commercially reasonable non-disclosure agreement with Licensee before proceeding with the verification.  If such verification shows that Licensee is using a greater number of copies of the Software than that legitimately licensed, is exceeding any applicable License Metric, or is deploying or using the Software in any way not permitted under this Agreement and which would require additional license fees, Licensee shall pay the applicable fees for such additional usage rights or copies within thirty (30) days of invoice date, with such underpaid fees being the license fees as per Adobe&apos;s then-current, country specific, license fee list.  If underpaid fees are in excess of five percent (5%) of the value of the fees paid under this Agreement, then Licensee shall pay such underpaid fees and Adobe&apos;s reasonable costs of conducting the verification.  This Section shall survive expiration or termination of this Agreement for a period of two (2) years.&#xA;&#xA;11.&#x9;Confidentiality.  Licensee agrees that Licensee will treat the License Keys (&quot;Confidential Information&quot;) with the same degree of care to prevent unauthorized disclosure to anyone other than Authorized Users as Licensee accords to Licensee&apos;s own confidential information, but in no event less than reasonable care. Licensee may disclose the Confidential Information in response to a valid order by a court or other governmental body, when otherwise required by law, or when necessary to establish the rights of either party under this Agreement, provided Licensee gives Adobe advance written notice thereof.&#xA;&#xA;12.&#x9;Specific Provisions and Exceptions. This Section sets forth specific provisions related to certain components of the Software as well as limited exceptions to the above terms and conditions. To the extent that any provision in this Section is in conflict with any other term or condition in this agreement, this Section will supersede such other term or condition.&#xA;12.1&#x9;Limited Warranty for Users Residing in Germany or Austria. If Licensee obtained the Software in Germany or Austria, and Licensee usually resides in such country, then Section 7 does not apply; instead, Adobe warrants that the Software provides the functionalities set forth in the Documentation (the &quot;agreed upon functionalities&quot;) for the limited warranty period following receipt of the Software when used on the recommended operating system, platform and hardware configuration.  As used in this Section, &quot;limited warranty period&quot; means one (1) year if Licensee is a business user and two (2) years if Licensee is not a business user. Non-substantial variation from the agreed upon functionalities will not and does not establish any warranty rights. This limited warranty does not apply to SAMPLE CODE, PATCHES, FONT software converted into other formats, OR SOFTWARE THAT HAS BEEN ALTERED BY LICENSEE TO THE EXTENT SUCH ALTERATION CAUSED A DEFECT. To make a warranty claim, during the limited warranty period Licensee must return, at Adobe&apos;s expense, the Software and proof of purchase to the location where Licensee obtained it. If the functionalities of the Software vary substantially from the agreed upon functionalities, Adobe is entitled -- by way of re-performance and at its own discretion -- to repair or replace the Software. If this fails, Licensee is entitled to a reduction of the purchase price (reduction) or to cancel the purchase agreement (rescission). For further warranty information, please contact the Adobe Customer Support Department.&#xA;12.2&#x9;Limitation of Liability for Users Residing in Germany and Austria.&#xA;12.2.1&#x9;If Licensee obtained the Software in Germany or Austria, and Licensee usually resides in such country, then Section 8 does not apply. Instead, subject to the provisions in Section 12.2.2, Adobe and its affiliates&apos; statutory liability for damages will be limited as follows:  (i) Adobe and its affiliates will be liable only up to the amount of damages as typically foreseeable at the time of entering into the purchase agreement in respect of damages caused by a slightly negligent breach of a material contractual obligation and (ii) Adobe and its affiliates will not be liable for damages caused by a slightly negligent breach of a non-material contractual obligation.&#xA;12.2.2&#x9;The aforesaid limitation of liability will not apply to any mandatory statutory liability, in particular, to liability under the German Product Liability Act, liability for assuming a specific guarantee or liability for culpably caused personal injuries.&#xA;12.2.3&#x9;Licensee is required to take all reasonable measures to avoid and reduce damages, in particular to make back-up copies of the Software and Licensee&apos;s computer data subject to the provisions of this agreement.&#xA;&#xA;13.&#x9;Term and Termination. This Agreement shall remain in effect until any material breach of this Agreement by Licensee occurs, upon which this Agreement shall automatically terminate. Upon termination of this Agreement for any reason, Licensee shall discontinue use of the Software and shall destroy the Software, Documentation and all copies thereto. Termination shall not, however, relieve either party of obligations incurred prior to the termination. The following Sections shall survive termination of this Agreement: 1 (Definitions), 3 (Intellectual Property Rights), 5.2 (Disclaimer), 6 (Limitation of Liability), 7 (Governing Law), 8 (General Provisions), 9 (Notice to U.S. Government End Users), 11 (Confidentiality), 12 (Specific Provisions and Exceptions), 13 (Term and Termination) and 14 (Third-Party Beneficiary).&#xA;&#xA;14.&#x9;Third-Party Beneficiary. Licensee acknowledges and agrees that Adobe&apos;s licensors (and/or Adobe if Licensee obtained the Software from any party other than Adobe) are third party beneficiaries of this Agreement, with the right to enforce the obligations set forth herein with respect to the respective technology of such licensors and/or Adobe.&#xA;&#xA;15.&#x9;Pre-release Software Additional Terms. If the Software is pre-commercial release or beta software (&quot;Pre-release Softwareâ?), then this section applies. The Pre-release Software is a pre-release version, does not represent final product from Adobe, and may contain bugs, errors and other problems that could cause system or other failures and data loss. Adobe may never commercially release the Pre-release Software. If you received the Pre-release Software pursuant to a separate written agreement, such as the Adobe Systems Incorporated License Agreement for Pre-release Software, your use of the Software is also governed by such agreement. You will return or destroy all copies of Pre-release Software upon request by Adobe or upon Adobe&apos;s commercial release of such Software. YOUR USE OF PRE-RELEASE SOFTWARE IS AT YOUR OWN RISK. SEE SECTIONS 5 AND 6 FOR WARRANTY DISCLAIMERS AND LIABILITY LIMITATIONS WHICH GOVERN PRE-RELEASE SOFTWARE.&#xA;&#xA;If Licensee has any questions regarding this agreement or if Licensee wishes to request any information from Adobe please use the address and contact information included with this product to contact the Adobe office serving Licensee&apos;s jurisdiction.&#xA;&#xA;Adobe and LiveCycle are either registered trademarks or trademarks of Adobe Systems Incorporated in the United States and/or other countries.  All other trademarks are the property of their respective owners.&#xA;&#xA;&#xA;&#xA;Adobe Application Modeling Plugin EULA 092110'/>
        <property name='df_LT.description' value='RDS Core and Database Components'/>
        <property name='df_LT.providerName' value='Adobe Systems Incorporated'/>
        <property name='df_LT.featureName' value='RDS Core and Database Components'/>
        <property name='df_LT.copyright' value='(c) 2004-2010 Adobe Systems Incorporated and its licensors. All Rights Reserved.&#xA;&#xA;Adobe, the Adobe logo, Flash and Flash Builder are either registered trademarks or&#xA;trademarks of Adobe Systems Incorporated in the United States and/or other countries.&#xA;&#xA;Built on Eclipse is a trademark of the Eclipse foundation, Inc.  All other trademarks&#xA;are the property of their respective owners.&#xA;&#xA;Protected by U.S Patents. Patents Pending in the U.S and/or other countries.&#xA;&#xA;Third Party Software Notices and/or Additional Terms and Conditions found at&#xA;http://www.adobe.com/go/thirdparty'/>
      </properties>
      <provides size='2'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='com.adobe.rds.feature.feature.group' version='4.5.304901.v20110217'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='11'>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.swt' range='0.0.0'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ui' range='0.0.0'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.runtime' range='0.0.0'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.resources' range='0.0.0'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.jface.text' range='0.0.0'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ui.editors' range='0.0.0'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ui.workbench.texteditor' range='0.0.0'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ui.ide' range='0.0.0'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='com.adobe.rds.core' range='[4.5.304901.v20110217,4.5.304901.v20110217]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='com.adobe.rds.dataview' range='[4.5.304901.v20110217,4.5.304901.v20110217]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='com.adobe.rds.feature.feature.jar' range='[4.5.304901.v20110217,4.5.304901.v20110217]'>
          <filter>
            (org.eclipse.update.install.features=true)
          </filter>
        </required>
      </requires>
      <touchpoint id='null' version='0.0.0'/>
      <licenses size='1'>
        <license uri='%25licenseURL' url='%25licenseURL'>
          %license
        </license>
      </licenses>
      <copyright>
        %copyright
      </copyright>
    </unit>
    <unit id='epp.package.java' version='1.3.1.20100916-1202'>
      <update id='epp.package.java' range='0.0.0' severity='0'/>
      <properties size='3'>
        <property name='org.eclipse.equinox.p2.name' value='Eclipse IDE for Java Developers'/>
        <property name='lineUp' value='true'/>
        <property name='org.eclipse.equinox.p2.type.group' value='true'/>
      </properties>
      <provides size='1'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='epp.package.java' version='1.3.1.20100916-1202'/>
      </provides>
      <requires size='8'>
        <required namespace='org.eclipse.equinox.p2.iu' name='tooling.source.default' range='[1.0.0,1.0.0]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='config.a.jre.javase' range='[1.6.0,1.6.0]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='toolingepp.package.java.configuration' range='[1.3.1.20100916-1202,1.3.1.20100916-1202]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='tooling.org.eclipse.update.feature.default' range='[1.0.0,1.0.0]'>
          <filter>
            (org.eclipse.update.install.features=true)
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='a.jre.javase' range='[1.6.0,1.6.0]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='tooling.osgi.bundle.default' range='[1.0.0,1.0.0]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.platform.ide' range='0.0.0'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.epp.package.java.feature.feature.group' range='[1.3.1.20100916-1202,1.3.1.20100916-1202]'/>
      </requires>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='2'>
          <instruction key='configure'>
            org.eclipse.equinox.p2.touchpoint.eclipse.addRepository(type:0,location:http${#58}//download.eclipse.org/tools/mylyn/update/helios,name:Mylyn for Eclipse Helios);org.eclipse.equinox.p2.touchpoint.eclipse.addRepository(type:1,location:http${#58}//download.eclipse.org/tools/mylyn/update/helios,name:Mylyn for Eclipse Helios);
          </instruction>
          <instruction key='unconfigure'>
            org.eclipse.equinox.p2.touchpoint.eclipse.removeRepository(type:0,location:http${#58}//download.eclipse.org/tools/mylyn/update/helios);org.eclipse.equinox.p2.touchpoint.eclipse.removeRepository(type:1,location:http${#58}//download.eclipse.org/tools/mylyn/update/helios);
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.cvs_root' version='1.2.0.v20100427-7B77FKt90GE5h0SBT5FV9A01911'>
      <provides size='1'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.cvs_root' version='1.2.0.v20100427-7B77FKt90GE5h0SBT5FV9A01911'/>
      </provides>
      <artifacts size='1'>
        <artifact classifier='binary' id='org.eclipse.cvs_root' version='1.2.0.v20100427-7B77FKt90GE5h0SBT5FV9A01911'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.native' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='2'>
          <instruction key='uninstall'>
            cleanupzip(source:@artifact, target:${installFolder});
          </instruction>
          <instruction key='install'>
            unzip(source:@artifact, target:${installFolder});
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.jdt_root' version='3.6.1.r361_v20100714-0800-7z8XFUSFLFlmgLc5z-Bvrt8-HVkH'>
      <provides size='1'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.jdt_root' version='3.6.1.r361_v20100714-0800-7z8XFUSFLFlmgLc5z-Bvrt8-HVkH'/>
      </provides>
      <artifacts size='1'>
        <artifact classifier='binary' id='org.eclipse.jdt_root' version='3.6.1.r361_v20100714-0800-7z8XFUSFLFlmgLc5z-Bvrt8-HVkH'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.native' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='2'>
          <instruction key='uninstall'>
            cleanupzip(source:@artifact, target:${installFolder});
          </instruction>
          <instruction key='install'>
            unzip(source:@artifact, target:${installFolder});
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.platform_root' version='3.6.1.r361_v20100909-9gF78GrkFqw7GrsZnvz0JWNTeb6fue6896L'>
      <provides size='1'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.platform_root' version='3.6.1.r361_v20100909-9gF78GrkFqw7GrsZnvz0JWNTeb6fue6896L'/>
      </provides>
      <artifacts size='1'>
        <artifact classifier='binary' id='org.eclipse.platform_root' version='3.6.1.r361_v20100909-9gF78GrkFqw7GrsZnvz0JWNTeb6fue6896L'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.native' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='2'>
          <instruction key='uninstall'>
            cleanupzip(source:@artifact, target:${installFolder});
          </instruction>
          <instruction key='install'>
            unzip(source:@artifact, target:${installFolder});
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.rcp.configuration_root.win32.win32.x86' version='1.0.0.M20100909-0800'>
      <provides size='1'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.rcp.configuration_root.win32.win32.x86' version='1.0.0.M20100909-0800'/>
      </provides>
      <filter>
        (&amp;(osgi.arch=x86)(osgi.os=win32)(osgi.ws=win32))
      </filter>
      <artifacts size='1'>
        <artifact classifier='binary' id='org.eclipse.rcp.configuration_root.win32.win32.x86' version='1.0.0.M20100909-0800'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.native' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='2'>
          <instruction key='uninstall'>
            cleanupzip(source:@artifact, target:${installFolder});
          </instruction>
          <instruction key='install'>
            unzip(source:@artifact, target:${installFolder});
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.rcp_root' version='3.6.1.r361_v20100827-9OArFLdFjY-ThSQXmKvKz0_T'>
      <provides size='1'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.rcp_root' version='3.6.1.r361_v20100827-9OArFLdFjY-ThSQXmKvKz0_T'/>
      </provides>
      <artifacts size='1'>
        <artifact classifier='binary' id='org.eclipse.rcp_root' version='3.6.1.r361_v20100827-9OArFLdFjY-ThSQXmKvKz0_T'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.native' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='2'>
          <instruction key='uninstall'>
            cleanupzip(source:@artifact, target:${installFolder});
          </instruction>
          <instruction key='install'>
            unzip(source:@artifact, target:${installFolder});
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
  </units>
  <iusProperties size='10'>
    <iuProperties id='SharedProfile_epp.package.java' version='1.0.0.1301933617378'>
      <properties size='2'>
        <property name='org.eclipse.equinox.p2.internal.inclusion.rules' value='STRICT'/>
        <property name='org.eclipse.equinox.p2.base' value='true'/>
      </properties>
    </iuProperties>
    <iuProperties id='com.adobe.flexbuilder.feature.standalone.nl1.feature.group' version='4.5.0.308971'>
      <properties size='4'>
        <property name='org.eclipse.equinox.p2.type.root' value='true'/>
        <property name='org.eclipse.equinox.p2.internal.inclusion.rules' value='STRICT'/>
        <property name='org.eclipse.equinox.p2.type.lock' value='3'/>
        <property name='org.eclipse.equinox.p2.base' value='true'/>
      </properties>
    </iuProperties>
    <iuProperties id='com.adobe.model.feature.core.feature.group' version='4.5.304901.v20110217'>
      <properties size='4'>
        <property name='org.eclipse.equinox.p2.type.root' value='true'/>
        <property name='org.eclipse.equinox.p2.internal.inclusion.rules' value='STRICT'/>
        <property name='org.eclipse.equinox.p2.type.lock' value='3'/>
        <property name='org.eclipse.equinox.p2.base' value='true'/>
      </properties>
    </iuProperties>
    <iuProperties id='com.adobe.rds.feature.feature.group' version='4.5.304901.v20110217'>
      <properties size='4'>
        <property name='org.eclipse.equinox.p2.type.root' value='true'/>
        <property name='org.eclipse.equinox.p2.internal.inclusion.rules' value='STRICT'/>
        <property name='org.eclipse.equinox.p2.type.lock' value='3'/>
        <property name='org.eclipse.equinox.p2.base' value='true'/>
      </properties>
    </iuProperties>
    <iuProperties id='epp.package.java' version='1.3.1.20100916-1202'>
      <properties size='4'>
        <property name='org.eclipse.equinox.p2.type.root' value='true'/>
        <property name='org.eclipse.equinox.p2.internal.inclusion.rules' value='STRICT'/>
        <property name='org.eclipse.equinox.p2.type.lock' value='3'/>
        <property name='org.eclipse.equinox.p2.base' value='true'/>
      </properties>
    </iuProperties>
    <iuProperties id='org.eclipse.cvs_root' version='1.2.0.v20100427-7B77FKt90GE5h0SBT5FV9A01911'>
      <properties size='3'>
        <property name='unzipped|@artifact|/shared/technology/epp/epp_build/36/build/epp.package.java/win32.win32.x86/eclipse' value='/shared/technology/epp/epp_build/36/build/epp.package.java/win32.win32.x86/eclipse/notice.html|/shared/technology/epp/epp_build/36/build/epp.package.java/win32.win32.x86/eclipse/epl-v10.html|'/>
        <property name='org.eclipse.equinox.p2.type.lock' value='3'/>
        <property name='org.eclipse.equinox.p2.base' value='true'/>
      </properties>
    </iuProperties>
    <iuProperties id='org.eclipse.jdt_root' version='3.6.1.r361_v20100714-0800-7z8XFUSFLFlmgLc5z-Bvrt8-HVkH'>
      <properties size='3'>
        <property name='unzipped|@artifact|/shared/technology/epp/epp_build/36/build/epp.package.java/win32.win32.x86/eclipse' value='/shared/technology/epp/epp_build/36/build/epp.package.java/win32.win32.x86/eclipse/epl-v10.html|/shared/technology/epp/epp_build/36/build/epp.package.java/win32.win32.x86/eclipse/notice.html|'/>
        <property name='org.eclipse.equinox.p2.type.lock' value='3'/>
        <property name='org.eclipse.equinox.p2.base' value='true'/>
      </properties>
    </iuProperties>
    <iuProperties id='org.eclipse.platform_root' version='3.6.1.r361_v20100909-9gF78GrkFqw7GrsZnvz0JWNTeb6fue6896L'>
      <properties size='3'>
        <property name='unzipped|@artifact|/shared/technology/epp/epp_build/36/build/epp.package.java/win32.win32.x86/eclipse' value='/shared/technology/epp/epp_build/36/build/epp.package.java/win32.win32.x86/eclipse/epl-v10.html|/shared/technology/epp/epp_build/36/build/epp.package.java/win32.win32.x86/eclipse/readme|/shared/technology/epp/epp_build/36/build/epp.package.java/win32.win32.x86/eclipse/readme/readme_eclipse.html|/shared/technology/epp/epp_build/36/build/epp.package.java/win32.win32.x86/eclipse/.eclipseproduct|/shared/technology/epp/epp_build/36/build/epp.package.java/win32.win32.x86/eclipse/notice.html|'/>
        <property name='org.eclipse.equinox.p2.type.lock' value='3'/>
        <property name='org.eclipse.equinox.p2.base' value='true'/>
      </properties>
    </iuProperties>
    <iuProperties id='org.eclipse.rcp.configuration_root.win32.win32.x86' version='1.0.0.M20100909-0800'>
      <properties size='3'>
        <property name='unzipped|@artifact|/shared/technology/epp/epp_build/36/build/epp.package.java/win32.win32.x86/eclipse' value='/shared/technology/epp/epp_build/36/build/epp.package.java/win32.win32.x86/eclipse/eclipsec.exe|/shared/technology/epp/epp_build/36/build/epp.package.java/win32.win32.x86/eclipse/eclipse.exe|'/>
        <property name='org.eclipse.equinox.p2.type.lock' value='3'/>
        <property name='org.eclipse.equinox.p2.base' value='true'/>
      </properties>
    </iuProperties>
    <iuProperties id='org.eclipse.rcp_root' version='3.6.1.r361_v20100827-9OArFLdFjY-ThSQXmKvKz0_T'>
      <properties size='3'>
        <property name='unzipped|@artifact|/shared/technology/epp/epp_build/36/build/epp.package.java/win32.win32.x86/eclipse' value='/shared/technology/epp/epp_build/36/build/epp.package.java/win32.win32.x86/eclipse/epl-v10.html|/shared/technology/epp/epp_build/36/build/epp.package.java/win32.win32.x86/eclipse/readme|/shared/technology/epp/epp_build/36/build/epp.package.java/win32.win32.x86/eclipse/readme/readme_eclipse.html|/shared/technology/epp/epp_build/36/build/epp.package.java/win32.win32.x86/eclipse/.eclipseproduct|/shared/technology/epp/epp_build/36/build/epp.package.java/win32.win32.x86/eclipse/notice.html|'/>
        <property name='org.eclipse.equinox.p2.type.lock' value='3'/>
        <property name='org.eclipse.equinox.p2.base' value='true'/>
      </properties>
    </iuProperties>
  </iusProperties>
</profile>
