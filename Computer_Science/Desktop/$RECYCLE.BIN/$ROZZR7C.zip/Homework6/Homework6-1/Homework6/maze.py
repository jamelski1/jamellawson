'''
  This is a Python GUI application, using the Tk framework, 
  partly described in Chapter 27. 

  The purpose of the Python GUI application is to put the user
  in a randomly selected maze of at least sixteen rooms with 
  connections between the rooms.  There is a room with treasure,
  and if the user moves to that room, the maze is solved:  the
  user wins!  To make the game interesting, there is one room
  with a dragon.  If the user moves to the room with the dragon,
  then the user loses (game over), EXCEPT if the user has a 
  sword.  So, there is a room with a sword.  When the user moves
  to the room with the sword, the user gains the sword and keeps
  it forever after.  Initially, the user has no sword and is in
  a room where there is neither sword nor dragon.  The maze is 
  set up so that there can be some way to win.  

  On the window for the application, the user can see buttons 
  that say what directions the user can move:  north, south, 
  east, west.  The window can also show labels about whether the
  user has a sword, and other status information.  Basically, the 
  user can just click on buttons and move from room to room.

  In addition to the information of Chapter 27, there is a 
  small, working GUI program in this directory, guisample.py, 
  that you can try.  It's not very nicely done, but does illustrate  
  a few widgets and some dynamic behavior.  Your application should
  be better than this.

  RULES FOR YOUR CODE 

      (a) No function or method can be longer than 20 lines!  
          (Except for comments and docstrings, which do not count 
          for the 20 lines) 

          "Cheating" around the 20 line restriction, like using 
          semicolon, extended lines with continuation (backslash)
          or combining one-line bodies --- tricks NOT ALLOWED.

      (b) All functions/methods must be documented, to say what is the
          purpose, what are the arguments (if any), and what are
          the output(s), what are the intended goals and effects. 

      (c) The way that the program represents the game, how the 
          user location and other information is represented, should
          be described in comments or a docstring.  

  8.  Grading/Scoring criteria:

      (i)   Does it work?
      (ii)  Does it follow the rules (a)-(c) above?  
      (iii) Does the code follow the original plan for documentation 
            on the functions/methods? 
      (iv)  Originality/Features:  does your Python application go 
            beyond the bare minimum of buttons and text, say with 
            colors, other widgets and interactive behaviors? 
''' 

''' Player 1 always starts off in room 0 with an empty holster.  The rooms are a dictionary
keys from 0 - 15 (adding up to 16 entire rooms). The Player 1 may be prompted for
their name and gender to fill in the different times the characters speak to the
Player 1 (depending on if this is possible).  The user will receive a short
paragraph describing the rules and directions and setting such as the house he's
in the situation with his family how he may not leave the house, how there is
a sword to find, how there is a dragon to slay etc.  The buttons will say North,
South, East, West.  The entire maze will be 4X4 equaling 16 rooms.  I will import
random module.  Assign the values to the the dictionary between 0 - 15.
The values will consist of family names which will be the name of the room.
The values will be Mom, Dad, Grandma, Grandpa, Sister, Brother,
Grandson, Aunt, Uncle, Son, Daughter, Niece, Nephew, Wife/Husband, Grandaughter.
Dragon will be a variable and it will be random using int(random.choice(range(1,16)))
I will randomly assign the sword a room as well.  Using a while loop I will say
while False:
sword = int(random.choice(range(1-16)))
if dragon == sword
return False
else:
return True
This will make it so that sword and dragon always have 2 different random numbers
and therefore will start in 2 different rooms.  From there I will need to figure
out how to use the guisample to build a 4X4 rooms that can go north, east, south,
and west instead of just forward and backwards.  I will create a variable called
weapon that is set to False.  I will need to make a function
that tests if the player has found the sword everytime he enters a new room.
Probably an if statement. If Player == Sword weapon is set to True and the player
is alerted that he has gained the sword. If Player == Dragon and weapon == False
give the message that the player has died and delay for 5 seconds to give the
player time to read the message and system exit.  If Player == Dragon and
weapon == True give the player the message that he has slayed the dragon and
delay for 5 seconds to give the player time to read the message and system exit.
